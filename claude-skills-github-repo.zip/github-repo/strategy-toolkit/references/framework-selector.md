# Framework Selector Guide

## Decision Tree

Start with the user's core question and follow the path:

### "I need to understand my competitive environment"
-> **Five Forces Analysis** (industry-level profitability drivers)
-> Then layer **Porter's Strategy** (how to position within that industry)

### "I need to define or refine my strategy"
-> **Porter's What Is Strategy** (positioning, trade-offs, activity fit)
-> If the industry is commoditized or hyper-competitive -> add **Blue Ocean Strategy**
-> If the company needs a new revenue model -> add **Business Model Reinvention**

### "I need to build something that lasts beyond me"
-> **Vision Framework** (core ideology + envisioned future + BHAG)
-> Then **Strategic Principles** (translate vision into daily decision rules)

### "I have a strategy but it's not working"
-> First diagnose: is it a strategy problem or an execution problem?
-> If strategy is sound but results lag -> **Strategy Execution** (Neilson) + **Seven Rules** (Mankins/Steele)
-> If decisions are stuck -> **RAPID Decision Model**
-> If you cannot measure progress -> **Balanced Scorecard**

### "I need to enter a new market or launch a new product"
-> **Blue Ocean Strategy** (find uncontested space)
-> **Business Model Reinvention** (design the model)
-> **Five Forces** (assess industry attractiveness before entry)

### "I need to communicate strategy across the organization"
-> **Strategic Principles** (one phrase that guides frontline decisions)
-> **Balanced Scorecard** (translate strategy into measurable objectives)

## Framework Compatibility Matrix

Frameworks that naturally combine:

| Combination | Why It Works |
|---|---|
| Five Forces + Porter's Strategy | Diagnose industry, then position within it |
| Blue Ocean + Business Model | Find new space, then design the model to capture it |
| Vision + Strategic Principles | Define where you are going, then create the decision rule |
| Execution + RAPID + Scorecard | Fix execution, clarify decisions, measure progress |
| Seven Rules + Balanced Scorecard | Close the strategy-to-performance gap and track it |
| Porter's Strategy + Activity System | Define position, then map the reinforcing activities |

## Frameworks That Should NOT Be Combined Carelessly

- **Porter's Strategy** and **Blue Ocean** have fundamentally different worldviews. Porter says choose a position within an existing industry. Blue Ocean says create a new market space. These can complement each other, but don't present them as saying the same thing. Be explicit about the tension.
- **Balanced Scorecard** is a measurement and management system, not a strategy itself. Never let a scorecard exercise substitute for actual strategic choices.

## Quick Reference: All 10 Frameworks

1. **Porter's What Is Strategy** - Strategy is about choosing a unique position through a distinctive set of activities. Not the same as operational effectiveness.
2. **Five Competitive Forces** - Industry profitability is shaped by five forces: rivalry, new entrants, substitutes, buyer power, supplier power.
3. **Building Your Company's Vision** - Enduring companies have a core ideology (values + purpose) that never changes and an envisioned future (BHAG + vivid description) that drives progress.
4. **Reinventing Your Business Model** - A business model has four interlocking elements: customer value proposition, profit formula, key resources, key processes.
5. **Blue Ocean Strategy** - Create uncontested market space by simultaneously pursuing differentiation and low cost through the Eliminate-Reduce-Raise-Create framework.
6. **Secrets to Successful Strategy Execution** - Execution depends on four building blocks in order of importance: decision rights, information flow, motivators, structure.
7. **Balanced Scorecard** - Measure strategy across four perspectives: financial, customer, internal processes, learning and growth.
8. **Strategic Principles** - Distill strategy into a single memorable, actionable phrase that guides frontline decisions.
9. **Turning Great Strategy into Great Performance** - Seven rules to close the strategy-to-performance gap where companies typically realize only 63% of their strategy's potential value.
10. **RAPID Decision Model** - Clarify decision roles: Recommend, Agree, Perform, Input, Decide.
