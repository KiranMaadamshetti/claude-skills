# Reinventing Your Business Model

Source: Mark W. Johnson, Clayton M. Christensen, Henning Kagermann, Harvard Business Review

## Core Concept

A great product wrapped in a mediocre business model will fail. A good product wrapped in a great business model can reshape industries. Most companies fail at innovation not because their technology is weak, but because their business model is wrong.

A business model consists of four interlocking elements. Changing any one element ripples through the others.

## The Four Elements

### 1. Customer Value Proposition (CVP)
The most important element. A successful CVP helps customers perform a specific "job" that alternative offerings fail to address.

**The Job-to-Be-Done framework:**
- What "job" is the customer trying to get done?
- What are the existing solutions and why do they fall short?
- What is the gap between the current best solution and the ideal?

The stronger the job's importance, the lower the satisfaction with current options, and the better your solution, the stronger your CVP.

**Example:** MinuteClinics succeeded not by being better hospitals, but by addressing a different job: "Help me get treated for a minor ailment conveniently and quickly without an appointment."

### 2. Profit Formula
How the company creates value for ITSELF while delivering value to customers.

Components:
- **Revenue model** - Price x volume. How much can you charge? What's the expected volume?
- **Cost structure** - Fixed vs variable costs. Which costs are most critical to manage?
- **Margin model** - Given price and costs, what margin per transaction is needed?
- **Resource velocity** - How quickly must resources be used to support expected volume? (inventory turns, asset utilization, throughput)

### 3. Key Resources
The people, technology, products, facilities, equipment, channels, and brand required to deliver the CVP profitably.

Focus on resources that create competitive differentiation, not generic requirements that any business needs.

### 4. Key Processes
Operational and managerial processes that allow repeatable, scalable value delivery.

Includes: design, development, sourcing, manufacturing, marketing, HR, IT processes. Also includes rules, metrics, and norms that make the processes work.

## When to Reinvent Your Business Model

Five strategic circumstances that demand business model innovation:

1. **Disruptive innovation opportunity** - chance to serve large groups of non-consumers with a simpler, cheaper solution
2. **New technology commercialization** - wrapping a new technology in the right business model
3. **Job-to-be-done opportunity** - addressing an unmet job in a market where no satisfactory solution exists
4. **Low-end disruption defense** - responding to competitors eating your market from below
5. **Responding to a shifting basis of competition** - commoditization forces fundamental model change

## Application Methodology

1. **Start with the CVP, not the product.** Define the job-to-be-done clearly.
2. **Design the profit formula** - What price will customers pay? Work backward from there to required cost structure and margins.
3. **Identify key resources and processes** needed to deliver the CVP at the profit formula's requirements
4. **Compare to your current model** - Where are the conflicts? A truly new business model will violate some rules of the existing model.
5. **Test the four elements for internal consistency** - Do they reinforce each other?

## Business Model Canvas (Application Template)

| Element | Current Model | New Model |
|---|---|---|
| Customer Value Proposition | [What job are you doing for customers today?] | [What job will you do differently?] |
| Profit Formula | [Revenue model, cost structure, margins, velocity] | [How does it change?] |
| Key Resources | [Critical assets and capabilities] | [What new resources needed?] |
| Key Processes | [Core operational processes] | [What must change?] |

## Common Pitfalls

- Starting with the solution instead of the customer's job-to-be-done
- Trying to run a new business model within the constraints of the existing model
- Underestimating how much the profit formula must change (most failed innovations use the old margin model)
- Ignoring the fact that key processes are deeply embedded and resistant to change
