# Resume Analyser — Claude Skill

**An intensive resume analysis and rewriting skill for Claude AI.**

## Quick Install

1. Download [`resume-analyser.skill`](resume-analyser.skill)
2. Go to [claude.ai](https://claude.ai) → Settings → Profile → Skills → Add Skill
3. Upload the file
4. Upload any resume and say **"Review my resume"**

## What It Does

Upload a resume (PDF, DOCX, or TXT) and get two deliverables:

### 1. Analysis Report
- Overall score out of 100 with letter grade
- 10-dimension breakdown (Impact, ATS, Relevance, Structure, Formatting, Language, Skills, Career Narrative, Digital Presence, Compliance)
- Section-by-section critique with severity tags
- Before/After rewrite examples
- ATS compatibility audit with keyword gap analysis
- Priority action plan (top 5 changes ranked by impact)

### 2. Complete Revised Resume
- Every bullet rewritten with the CAR framework (Challenge → Action → Result)
- Professional Summary replaces generic Objectives
- Skills properly categorized
- Outdated sections removed
- Copy-to-clipboard button
- All inferred numbers marked as `[PLACEHOLDER: ...]` — nothing fabricated

## Example Prompts

```
Review my resume
```
```
Score my resume and rewrite it for a Data Analyst role
```
```
Analyse my CV against this job description: [paste JD]
```
```
Is my resume ATS-friendly? Fix any issues.
```

## Skill Contents

| File | Purpose |
|------|---------|
| `SKILL.md` | Core instructions — 9-step workflow from extraction to delivery |
| `references/scoring-rubric.md` | Detailed grading criteria for all 10 dimensions |
| `scripts/generate_report.py` | HTML report template with dual-tab layout (Analysis + Revised Resume) |

## How Scoring Works

| Dimension | Weight |
|-----------|--------|
| Impact & Achievements | 20% |
| ATS Compatibility | 15% |
| Content Relevance | 12% |
| Structure & Flow | 10% |
| Formatting & Readability | 10% |
| Language & Grammar | 8% |
| Skills Presentation | 8% |
| Career Narrative | 7% |
| Digital Presence | 5% |
| Compliance & Red Flags | 5% |

**Grade Scale:** A+ (90-100) → A (85-89) → B+ (75-79) → B (70-74) → C (55-59) → D (40-44) → F (below 40)
