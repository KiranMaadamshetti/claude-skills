---
name: strategy-toolkit
description: >-
  Comprehensive strategy analysis toolkit with 10 proven strategic
  frameworks. Use this skill whenever a user asks about business strategy,
  competitive analysis, strategic planning, market positioning, business
  model design, strategy execution, or organizational decision-making.
  Triggers include phrases like help me build a strategy, analyse my
  competitive position, five forces analysis, blue ocean, business model
  canvas, balanced scorecard, strategic planning, competitive advantage,
  market entry strategy, growth strategy, strategy execution, BHAG,
  vision and mission, how to compete, industry analysis, or any request
  involving strategic thinking for a company or business unit. Also
  trigger when the user describes a business problem that requires
  strategic framing even if they do not use the word strategy.
---

# Strategy Toolkit

A comprehensive strategy analysis system built from 10 seminal strategic frameworks. This skill helps users develop, analyse, and execute business strategy using the most proven strategic thinking tools available.

## When to Use Which Framework

Before diving into analysis, select the right framework for the problem. Read `references/framework-selector.md` for the complete decision guide. Quick map:

| User's Problem | Primary Framework | Supporting Frameworks |
|---|---|---|
| "How do I compete?" / "What's my strategy?" | Porter's What Is Strategy | Five Forces, Blue Ocean |
| "How attractive is this industry?" | Five Forces Analysis | Porter's Strategy (positioning) |
| "How do I find uncontested market space?" | Blue Ocean Strategy | Business Model Reinvention |
| "How do I build a lasting company?" | Vision Framework (Collins/Porras) | Strategic Principles |
| "How do I redesign my business model?" | Business Model Reinvention | Blue Ocean, Porter's Strategy |
| "My strategy isn't working" / "Execution gap" | Strategy Execution (Neilson) | Balanced Scorecard, Seven Rules |
| "How do I measure strategic progress?" | Balanced Scorecard | Strategy-to-Performance Gap |
| "How do I communicate strategy to frontline?" | Strategic Principles (Gadiesh) | Vision Framework |
| "We keep missing our targets" | Seven Rules (Mankins/Steele) | Execution, RAPID Decisions |
| "Decisions are stuck / too slow" | RAPID Decision Model | Execution framework |

## Core Workflow

For any strategy request, follow this sequence:

```
1. DIAGNOSE  -> Understand the user's situation, industry, and core challenge
2. SELECT    -> Pick 1-3 frameworks most relevant to their problem
3. ANALYSE   -> Apply frameworks systematically with the user's specific data
4. SYNTHESIZE -> Combine insights into a coherent strategic narrative
5. RECOMMEND -> Provide specific, actionable strategic recommendations
6. DELIVER   -> Output as structured document or interactive report
```

### Step 1: DIAGNOSE

Before applying any framework, understand:
- What business or business unit are we analysing?
- What industry and what competitive context?
- What is the core strategic question or challenge?
- What stage is the company at (startup, growth, mature, turnaround)?
- What data does the user have available?

If the user provides a vague request like "help me with strategy", ask targeted questions. But if they provide enough context, jump straight into analysis.

### Step 2: SELECT Frameworks

Read `references/framework-selector.md` for the detailed selection guide. Key principle: almost no strategic problem needs all 10 frameworks. Pick 1-3 that directly address the user's core question. Layer them for depth.

**Common combinations:**
- Industry entry: Five Forces + Blue Ocean + Business Model
- Competitive positioning: Porter's Strategy + Five Forces + Activity System Mapping
- Growth strategy: Blue Ocean + Business Model Reinvention + Vision Framework
- Performance turnaround: Seven Rules + Execution Framework + RAPID Decisions
- Strategic planning: Vision + Porter's Strategy + Balanced Scorecard

### Step 3: ANALYSE Using Frameworks

For each selected framework, read its reference file and apply systematically:

| Framework | Reference File |
|---|---|
| Porter's What Is Strategy | `references/porter-strategy.md` |
| Five Competitive Forces | `references/five-forces.md` |
| Blue Ocean Strategy | `references/blue-ocean.md` |
| Building Company Vision | `references/vision-framework.md` |
| Business Model Reinvention | `references/business-model.md` |
| Strategy Execution | `references/strategy-execution.md` |
| Balanced Scorecard | `references/balanced-scorecard.md` |
| Strategic Principles | `references/strategic-principles.md` |
| Strategy-to-Performance Gap | `references/strategy-performance.md` |
| RAPID Decision Model | `references/rapid-decisions.md` |

Each reference file contains:
- The core concept and why it matters
- Step-by-step application methodology
- Key questions to ask
- Common pitfalls to avoid
- Output template

### Step 4: SYNTHESIZE

After running individual frameworks, synthesize findings into a unified strategic narrative:

1. **Strategic diagnosis** - What is the fundamental challenge? (one clear sentence)
2. **Core insight** - What did the analysis reveal that was not obvious before?
3. **Strategic choice** - What is the recommended path, and what is being deliberately chosen against?
4. **Activity system** - What set of reinforcing activities will deliver the strategy?
5. **Execution priorities** - What are the 3-5 most critical things to get right first?

### Step 5: RECOMMEND

Recommendations must be:
- **Specific** - not "improve operations" but "reduce order-to-delivery cycle from 14 days to 5 days by automating X and Y"
- **Grounded in trade-offs** - explicitly state what you are choosing NOT to do
- **Time-bound** - short-term (0-6 months), medium-term (6-18 months), long-term (18-36 months)
- **Measurable** - each recommendation has a success metric
- **Honest about risks** - flag the biggest uncertainties and what could go wrong

### Step 6: DELIVER

**For comprehensive analysis**, generate an HTML report with:
- Executive summary with strategic diagnosis
- Framework-by-framework analysis with visualizations
- Synthesized strategic recommendations
- Implementation roadmap
- Key metrics to track

**For focused questions**, respond conversationally but structured, using the relevant framework as a thinking scaffold without necessarily naming every concept.

**For business plans or documents**, generate the analysis as a polished Word document or Markdown file.

## Applying Frameworks to Indian/Emerging Market Context

Since many users will be analysing businesses in India or other emerging markets, adapt frameworks accordingly:

- **Five Forces in India**: Consider regulatory forces as a de facto sixth force. Government policy, licensing, and compliance costs materially shape industry profitability.
- **Blue Ocean in emerging markets**: Massive unserved populations create natural blue ocean opportunities. Look for non-consumption (people who cannot currently access a service at all).
- **Business model innovation**: Frugal innovation and last-mile distribution are critical in Tier 2-5 markets. Unit economics must work at lower price points with higher volumes.
- **Strategy execution**: In relationship-driven markets, information flow and decision rights frameworks are especially important because informal power structures often override formal ones.
- **NBFC/Financial services context**: For lending businesses, competitive forces include regulatory capital requirements, RBI/NHB guidelines, geographic reach constraints, and borrower segment targeting as key strategic choices.

## Output Quality Standards

- Always ground analysis in the user's specific situation, not generic advice
- Use the frameworks as thinking tools, not checklists to mechanically fill in
- Prioritize insight over completeness. A sharp diagnosis with 2 frameworks beats a shallow pass through 10
- When data is missing, state assumptions clearly and note sensitivity
- Visualize where it helps (industry maps, activity systems, strategy canvases)
- Never just describe what a framework is. Apply it to generate insight the user did not already have
