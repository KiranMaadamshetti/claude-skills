# The Secrets to Successful Strategy Execution

Source: Gary L. Neilson, Karla L. Martin, Elizabeth Powers, Harvard Business Review

## Core Concept

A brilliant strategy is worthless without solid execution. Most companies struggle with implementation because they reach for the wrong levers. The research (based on surveys of over 26,000 people across 31 companies) reveals a clear hierarchy of what matters most for execution.

**The critical finding:** Structure is the LEAST effective lever for improving execution. Decision rights and information flow matter far more.

## The Four Building Blocks (in order of importance)

### 1. Decision Rights (Most Important)
Everyone in the organization must know which decisions and actions they are responsible for. Ambiguity in decision rights is the number one execution killer.

**Key indicators of broken decision rights:**
- Decisions get revisited or overturned after being made
- The same decision gets made multiple times at different levels
- People are unsure who has the authority to make key decisions
- Line managers second-guess functional heads (or vice versa)

**Fixes:**
- Clearly specify who owns each type of decision
- Push decisions down to the level where the best information exists
- Ensure field and line employees have the authority to make decisions that directly affect customer-facing operations
- Create clear escalation paths for when decisions need to go up

### 2. Information Flow (Second Most Important)
Information must flow freely across organizational boundaries and up/down the hierarchy. People need the right information at the right time to make good decisions.

**Key indicators of broken information flow:**
- Frontline employees do not understand the competitive dynamics they are working in
- Field-level insights about customers and competitors do not reach senior leadership
- Cross-functional information sharing is poor
- Important information gets filtered or distorted as it moves up

**Fixes:**
- Promote managers laterally across units so they build cross-functional networks
- Create mechanisms for field intelligence to reach headquarters
- Ensure frontline employees understand the financial implications of their decisions
- Make competitive and customer information widely accessible

### 3. Motivators (Third)
Incentive systems, career paths, and recognition programs that align individual behavior with strategic objectives.

**Key indicators of broken motivators:**
- High performers are not distinguishably rewarded compared to average performers
- Promotions are based on tenure or politics rather than results
- Individual incentives conflict with team or organizational goals

### 4. Structure (Least Important for Execution)
Organizational structure matters, but restructuring alone rarely fixes execution. Structure is the blunt instrument that gets used too often because it feels decisive.

**When structure matters:** When decision rights are clear and information flows well but the organizational design fundamentally prevents coordination. Otherwise, fix the first three before touching structure.

## Application Methodology

1. **Diagnose** - For the strategy that is underperforming, ask:
   - Do people know who is responsible for which decisions?
   - Does information flow to where it needs to go?
   - Are incentives aligned with strategic priorities?
   - Does the structure enable or prevent execution?

2. **Prioritize** - Fix decision rights and information flow FIRST. These two levers account for more of the variance in execution effectiveness than motivators and structure combined.

3. **Implement in sequence** - Clarify decision rights, then ensure information flows support those decisions, then align motivators, then adjust structure only if needed.

## Common Pitfalls

- Reorganizing when the real problem is unclear decision rights (the most common mistake)
- Assuming that the person who made the strategy should also be the one executing it
- Focusing on structure because it is visible, while ignoring the invisible decision and information problems
- Treating execution as a separate phase from strategy (they should be developed together)
