#!/usr/bin/env python3
"""
Resume Analysis + Revised Resume Report Generator

Generates a self-contained HTML report with two tabs:
  Tab 1: Full analysis (scores, critique, ATS audit, action plan)
  Tab 2: Revised resume (rendered + copy-to-clipboard + placeholders checklist)

Expected analysis_data structure: see docstring at bottom.
"""

import json, sys, math, html as html_mod
from datetime import datetime


def esc(text):
    """HTML-escape user content."""
    return html_mod.escape(str(text))


def score_color(score):
    if score >= 8: return "#34d399"
    elif score >= 6: return "#fbbf24"
    elif score >= 4: return "#fb923c"
    else: return "#f87171"


def score_label(score):
    if score >= 9: return "Exceptional"
    elif score >= 7: return "Strong"
    elif score >= 5: return "Average"
    elif score >= 3: return "Weak"
    else: return "Critical"


def overall_grade(score):
    grades = [
        (90, "A+", "#34d399"), (85, "A", "#34d399"), (80, "A-", "#6ee7b7"),
        (75, "B+", "#a7f3d0"), (70, "B", "#fbbf24"), (65, "B-", "#fcd34d"),
        (60, "C+", "#fde68a"), (55, "C", "#fb923c"), (50, "C-", "#fdba74"),
        (45, "D+", "#f87171"), (40, "D", "#f87171"), (0, "F", "#ef4444")
    ]
    for threshold, grade, color in grades:
        if score >= threshold:
            return grade, color
    return "F", "#ef4444"


def sev_icon(s):
    return {"critical": "🔴", "important": "🟡", "minor": "🔵"}.get(s, "⚪")

def ats_icon(s):
    return {"pass": "✅", "warning": "⚠️", "fail": "❌"}.get(s, "❓")


def build_radar_svg(scores_list, grade_color):
    n = len(scores_list)
    cx, cy, r = 160, 160, 125
    # Grid
    grid = ""
    for frac in [0.25, 0.5, 0.75, 1.0]:
        grid += f'<circle cx="{cx}" cy="{cy}" r="{r*frac}" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="1"/>'
    # Axes
    axes = ""
    for i in range(n):
        angle = (2 * math.pi * i / n) - math.pi / 2
        x2 = cx + r * math.cos(angle)
        y2 = cy + r * math.sin(angle)
        axes += f'<line x1="{cx}" y1="{cy}" x2="{x2}" y2="{y2}" stroke="rgba(255,255,255,0.06)" stroke-width="1"/>'
    # Polygon
    pts = []
    for i, s in enumerate(scores_list):
        angle = (2 * math.pi * i / n) - math.pi / 2
        val = s["score"] / 10
        px = cx + r * val * math.cos(angle)
        py = cy + r * val * math.sin(angle)
        pts.append(f"{px:.1f},{py:.1f}")
    # Labels
    labels = ""
    for i, s in enumerate(scores_list):
        angle = (2 * math.pi * i / n) - math.pi / 2
        lx = cx + (r + 35) * math.cos(angle)
        ly = cy + (r + 35) * math.sin(angle)
        short = s["label"].split("&")[0].split("(")[0].strip()[:14]
        anchor = "middle"
        if lx < cx - 20: anchor = "end"
        elif lx > cx + 20: anchor = "start"
        labels += f'<text x="{lx:.1f}" y="{ly:.1f}" text-anchor="{anchor}" font-size="10" fill="#a1a1aa" dominant-baseline="middle" font-family="inherit">{esc(short)}</text>'
        # Score dot
        val = s["score"] / 10
        dx = cx + r * val * math.cos(angle)
        dy = cy + r * val * math.sin(angle)
        labels += f'<circle cx="{dx:.1f}" cy="{dy:.1f}" r="4" fill="{grade_color}" stroke="#0f1117" stroke-width="2"/>'

    return f'''<svg viewBox="0 0 320 320" width="300" height="300" xmlns="http://www.w3.org/2000/svg">
        {grid}{axes}
        <polygon points="{' '.join(pts)}" fill="{grade_color}20" stroke="{grade_color}" stroke-width="2.5" stroke-linejoin="round"/>
        {labels}
    </svg>'''


def build_scores_html(scores):
    rows = ""
    for key, info in scores.items():
        sc = info["score"]
        c = score_color(sc)
        lbl = score_label(sc)
        pct = sc * 10
        rows += f'''
        <div class="sc-row">
          <div class="sc-label"><span class="sc-name">{esc(info["label"])}</span><span class="sc-wt">{info["weight"]}%</span></div>
          <div class="sc-track"><div class="sc-fill" style="width:{pct}%;background:{c}"></div></div>
          <div class="sc-val" style="color:{c}">{sc}/10</div>
          <div class="sc-tag" style="background:{c}18;color:{c};border:1px solid {c}40">{lbl}</div>
        </div>
        <p class="sc-sum">{esc(info["summary"])}</p>'''
    return rows


def build_sections_html(sections):
    cards = ""
    for sec in sections:
        status_map = {
            "present": ("Present", "#34d399"),
            "missing": ("Missing", "#f87171"),
            "needs_improvement": ("Needs Work", "#fbbf24")
        }
        badge_text, badge_color = status_map.get(sec["status"], ("", "#888"))
        badge = f'<span class="badge" style="background:{badge_color}18;color:{badge_color};border:1px solid {badge_color}40">{badge_text}</span>'

        body_parts = ""
        # Strengths
        if sec.get("strengths"):
            items = "".join(f"<li>✓ {esc(s)}</li>" for s in sec["strengths"])
            body_parts += f'<div class="sub"><h4>Strengths</h4><ul>{items}</ul></div>'
        # Issues
        if sec.get("issues"):
            items = "".join(f'<li>{sev_icon(i["severity"])} <strong>{i["severity"].title()}:</strong> {esc(i["text"])}</li>' for i in sec["issues"])
            body_parts += f'<div class="sub"><h4>Issues Found</h4><ul>{items}</ul></div>'
        # Rewrites
        if sec.get("rewrites"):
            rw_html = ""
            for rw in sec["rewrites"]:
                rw_html += f'''<div class="rw-block">
                    <div class="rw-before"><span class="rw-label">✗ Before:</span> {esc(rw["before"])}</div>
                    <div class="rw-arrow">⬇</div>
                    <div class="rw-after"><span class="rw-label">✓ After:</span> {esc(rw["after"])}</div>
                    <div class="rw-why">{esc(rw["why"])}</div>
                </div>'''
            body_parts += f'<div class="sub"><h4>Suggested Rewrites</h4>{rw_html}</div>'

        cards += f'''<div class="sec-card">
            <div class="sec-hdr" onclick="this.parentElement.classList.toggle('open')">
                <div><h3>{esc(sec["name"])} {badge}</h3></div>
                <span class="chevron">›</span>
            </div>
            <div class="sec-body">{body_parts}</div>
        </div>'''
    return cards


def build_ats_html(ats):
    overall_icon = ats_icon(ats.get("overall", ""))
    checks = ""
    for c in ats.get("checks", []):
        icon = ats_icon(c["status"])
        checks += f'<div class="ats-row"><span class="ats-ico">{icon}</span><span class="ats-item">{esc(c["item"])}</span><span class="ats-detail">{esc(c["detail"])}</span></div>'

    kw = ats.get("keyword_analysis", {})
    found = ", ".join(kw.get("found", [])[:20]) or "—"
    missing = ", ".join(kw.get("missing", [])[:15]) or "—"
    rate = kw.get("match_rate")
    rate_html = f'<div class="kw-rate">Keyword Match: <strong>{rate}%</strong></div>' if rate else ""

    return f'''<h2>ATS Compatibility Audit {overall_icon}</h2>
    {checks}
    <div class="kw-box">
        {rate_html}
        <div><strong>Found:</strong> <span class="kw-found">{esc(found)}</span></div>
        <div style="margin-top:6px"><strong>Missing:</strong> <span class="kw-miss">{esc(missing)}</span></div>
    </div>'''


def build_actions_html(actions):
    items = ""
    for a in actions:
        ic = "#34d399" if a["impact"] == "high" else "#fbbf24"
        items += f'''<div class="act-item">
            <div class="act-rank">#{a["rank"]}</div>
            <div class="act-text">{esc(a["action"])}</div>
            <div class="act-tags">
                <span class="tag" style="background:{ic}18;color:{ic};border:1px solid {ic}40">Impact: {a["impact"].title()}</span>
                <span class="tag" style="background:#818cf818;color:#818cf8;border:1px solid #818cf840">Effort: {a["effort"].title()}</span>
            </div>
        </div>'''
    return items


def md_to_html(md_text):
    """Very basic markdown → HTML for the revised resume display."""
    lines = md_text.split("\n")
    html_lines = []
    in_ul = False
    for line in lines:
        stripped = line.strip()
        # Close list if needed
        if in_ul and not stripped.startswith("- ") and not stripped.startswith("* "):
            html_lines.append("</ul>")
            in_ul = False

        if stripped.startswith("# ") and not stripped.startswith("## "):
            html_lines.append(f'<h1 class="res-h1">{esc(stripped[2:])}</h1>')
        elif stripped.startswith("## "):
            html_lines.append(f'<h2 class="res-h2">{esc(stripped[3:])}</h2>')
        elif stripped.startswith("### "):
            html_lines.append(f'<h3 class="res-h3">{esc(stripped[4:])}</h3>')
        elif stripped.startswith("- ") or stripped.startswith("* "):
            if not in_ul:
                html_lines.append("<ul>")
                in_ul = True
            content = stripped[2:]
            # Highlight placeholders
            import re
            content = re.sub(
                r'\[PLACEHOLDER:\s*([^\]]+)\]',
                r'<span class="placeholder">[PLACEHOLDER: \1]</span>',
                esc(content)
            )
            # Bold
            content = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', content)
            html_lines.append(f"<li>{content}</li>")
        elif stripped.startswith("**") and stripped.endswith("**"):
            html_lines.append(f'<p class="res-bold">{esc(stripped[2:-2])}</p>')
        elif stripped == "":
            html_lines.append("<br>")
        elif stripped.startswith("**"):
            import re
            content = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', esc(stripped))
            content = re.sub(
                r'\[PLACEHOLDER:\s*([^\]]+)\]',
                r'<span class="placeholder">[PLACEHOLDER: \1]</span>',
                content
            )
            html_lines.append(f"<p>{content}</p>")
        else:
            import re
            content = re.sub(
                r'\[PLACEHOLDER:\s*([^\]]+)\]',
                r'<span class="placeholder">[PLACEHOLDER: \1]</span>',
                esc(stripped)
            )
            content = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', content)
            html_lines.append(f"<p>{content}</p>")

    if in_ul:
        html_lines.append("</ul>")
    return "\n".join(html_lines)


def build_placeholders_checklist(revised_md):
    """Extract all [PLACEHOLDER: ...] from the revised resume."""
    import re
    matches = re.findall(r'\[PLACEHOLDER:\s*([^\]]+)\]', revised_md)
    if not matches:
        return '<p style="color:#34d399">✅ No placeholders — the resume is complete as-is!</p>'
    items = ""
    for i, m in enumerate(matches, 1):
        items += f'<div class="ph-item"><input type="checkbox" id="ph{i}"><label for="ph{i}">{esc(m)}</label></div>'
    return f'<div class="ph-list"><h3>📋 Placeholders to Fill ({len(matches)} items)</h3><p class="ph-note">Search for [PLACEHOLDER: ...] in the text and replace with your actual numbers/details.</p>{items}</div>'


def generate_html(d):
    grade, gc = overall_grade(d["overall_score"])
    date = d.get("analysis_date", datetime.now().strftime("%B %d, %Y"))
    meta = d.get("meta", {})
    scores_list = list(d["scores"].values())

    radar_svg = build_radar_svg(scores_list, gc)
    scores_html = build_scores_html(d["scores"])
    sections_html = build_sections_html(d.get("sections", []))
    ats_html = build_ats_html(d.get("ats_audit", {}))
    actions_html = build_actions_html(d.get("priority_actions", []))

    revised_md = d.get("revised_resume_md", "")
    revised_rendered = md_to_html(revised_md)
    placeholders_html = build_placeholders_checklist(revised_md)

    # Escape the markdown for JS copy
    revised_for_js = revised_md.replace("\\", "\\\\").replace("`", "\\`").replace("$", "\\$").replace("</", "<\\/")

    target_html = f'<div class="meta-item"><strong>Target Role:</strong> {esc(meta["target_role"])}</div>' if meta.get("target_role") else ""

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Resume Analysis — {esc(d.get("candidate_name", "Report"))}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
:root{{--bg:#0c0e14;--card:#14171f;--card2:#1a1e28;--text:#e2e2e8;--text2:#8a8a9a;--border:#252836;--accent:#818cf8;--accent2:#6366f1}}
body{{font-family:'Segoe UI',system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--text);line-height:1.65}}
.wrap{{max-width:880px;margin:0 auto;padding:20px}}

/* Header */
.hdr{{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;flex-wrap:wrap;margin-bottom:28px}}
.hdr-info h1{{font-size:1.6rem;font-weight:700;letter-spacing:-0.5px}}
.hdr-info .sub{{color:var(--text2);font-size:.88rem;margin-top:2px}}
.grade-ring{{width:96px;height:96px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;font-weight:800;font-size:1.9rem;border:4px solid {gc};color:{gc};background:{gc}10;flex-shrink:0}}
.grade-ring .gs{{font-size:.65rem;font-weight:500;color:var(--text2);margin-top:-2px}}
.overall-num{{text-align:center;font-size:.82rem;color:var(--text2);margin-top:4px}}

/* Tabs */
.tabs{{display:flex;gap:0;margin-bottom:24px;border-bottom:2px solid var(--border)}}
.tab-btn{{padding:12px 28px;font-size:.92rem;font-weight:600;cursor:pointer;border:none;background:transparent;color:var(--text2);border-bottom:2px solid transparent;margin-bottom:-2px;transition:all .2s}}
.tab-btn:hover{{color:var(--text)}}
.tab-btn.active{{color:var(--accent);border-bottom-color:var(--accent)}}
.tab-panel{{display:none}}
.tab-panel.active{{display:block}}

/* Meta bar */
.meta{{display:flex;gap:20px;flex-wrap:wrap;padding:10px 16px;background:var(--card);border-radius:8px;border:1px solid var(--border);font-size:.82rem;margin-bottom:24px}}
.meta-item{{color:var(--text2)}}
.meta-item strong{{color:var(--text)}}

h2{{font-size:1.15rem;font-weight:600;margin:28px 0 14px;color:var(--accent);border-bottom:1px solid var(--border);padding-bottom:8px}}

/* Scores */
.radar-wrap{{display:flex;justify-content:center;margin:12px 0 20px}}
.sc-row{{display:grid;grid-template-columns:195px 1fr 48px 82px;align-items:center;gap:10px;padding:7px 0}}
.sc-name{{font-weight:500;font-size:.88rem}}
.sc-wt{{color:var(--text2);font-size:.72rem;margin-left:6px}}
.sc-track{{height:7px;background:var(--border);border-radius:4px;overflow:hidden}}
.sc-fill{{height:100%;border-radius:4px;transition:width .5s ease}}
.sc-val{{font-weight:700;font-size:.88rem;text-align:right}}
.sc-tag{{font-size:.68rem;font-weight:600;padding:2px 8px;border-radius:10px;text-align:center}}
.sc-sum{{color:var(--text2);font-size:.8rem;padding:0 0 10px;border-bottom:1px solid var(--border);margin-bottom:3px}}

/* Section cards */
.sec-card{{background:var(--card);border:1px solid var(--border);border-radius:8px;margin-bottom:6px;overflow:hidden}}
.sec-hdr{{display:flex;justify-content:space-between;align-items:center;padding:12px 16px;cursor:pointer;transition:background .15s}}
.sec-hdr:hover{{background:var(--card2)}}
.chevron{{color:var(--text2);font-size:1.1rem;transition:transform .2s;font-weight:700}}
.sec-card.open .chevron{{transform:rotate(90deg)}}
.sec-body{{display:none;padding:0 16px 14px}}
.sec-card.open .sec-body{{display:block}}
.sub{{margin-top:10px}}
.sub h4{{font-size:.78rem;font-weight:600;color:var(--text2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px}}
.sub ul{{padding-left:18px}}
.sub li{{margin-bottom:5px;font-size:.85rem}}
.badge{{font-size:.68rem;font-weight:600;padding:2px 10px;border-radius:10px;margin-left:8px}}

/* Rewrites */
.rw-block{{background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px;margin:6px 0;font-size:.84rem}}
.rw-label{{font-weight:600;margin-right:4px}}
.rw-before{{color:#f87171;padding:3px 0}}
.rw-arrow{{text-align:center;color:var(--text2);font-size:.9rem;padding:2px 0}}
.rw-after{{color:#34d399;padding:3px 0}}
.rw-why{{color:var(--text2);font-size:.78rem;margin-top:6px;font-style:italic;padding-top:6px;border-top:1px solid var(--border)}}

/* ATS */
.ats-row{{display:grid;grid-template-columns:28px 190px 1fr;gap:8px;align-items:start;padding:5px 0;font-size:.85rem;border-bottom:1px solid var(--border)}}
.ats-detail{{color:var(--text2)}}
.kw-box{{margin-top:14px;padding:12px;background:var(--card);border-radius:8px;font-size:.84rem;border:1px solid var(--border)}}
.kw-rate{{font-size:.95rem;font-weight:600;margin-bottom:8px}}
.kw-found{{color:#34d399}}
.kw-miss{{color:#f87171}}

/* Actions */
.act-item{{display:flex;align-items:flex-start;gap:12px;padding:12px;background:var(--card);border:1px solid var(--border);border-radius:8px;margin-bottom:6px}}
.act-rank{{font-size:1.15rem;font-weight:800;color:var(--accent);min-width:30px}}
.act-text{{flex:1;font-size:.88rem}}
.act-tags{{display:flex;gap:5px;flex-shrink:0;flex-wrap:wrap}}
.tag{{font-size:.68rem;font-weight:600;padding:2px 8px;border-radius:10px;white-space:nowrap}}

/* ====== REVISED RESUME TAB ====== */
.res-actions{{display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap}}
.btn{{padding:10px 22px;border-radius:8px;border:none;font-weight:600;font-size:.88rem;cursor:pointer;transition:all .15s}}
.btn-primary{{background:var(--accent);color:#fff}}
.btn-primary:hover{{background:var(--accent2)}}
.btn-secondary{{background:var(--card);color:var(--text);border:1px solid var(--border)}}
.btn-secondary:hover{{background:var(--card2)}}
.copy-ok{{color:#34d399;font-size:.85rem;margin-left:8px;display:none}}

.res-container{{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:32px 36px;max-width:720px;margin:0 auto}}
.res-h1{{font-size:1.5rem;font-weight:700;text-align:center;margin-bottom:2px;letter-spacing:-0.3px}}
.res-h2{{font-size:1rem;font-weight:600;color:var(--accent);border-bottom:2px solid var(--accent);padding-bottom:4px;margin:20px 0 10px;text-transform:uppercase;letter-spacing:.5px}}
.res-h3{{font-size:.92rem;font-weight:600;margin:12px 0 2px}}
.res-container p{{font-size:.86rem;margin:3px 0;color:var(--text)}}
.res-container ul{{padding-left:20px;margin:4px 0}}
.res-container li{{font-size:.86rem;margin-bottom:4px;color:var(--text)}}
.res-bold{{font-weight:600}}
.placeholder{{background:#fbbf2420;color:#fbbf24;padding:1px 6px;border-radius:4px;font-weight:600;border:1px dashed #fbbf2460}}

/* Placeholders checklist */
.ph-list{{background:var(--card);border:1px solid #fbbf2440;border-radius:10px;padding:20px;margin-top:24px}}
.ph-list h3{{font-size:1rem;margin-bottom:4px}}
.ph-note{{color:var(--text2);font-size:.82rem;margin-bottom:12px}}
.ph-item{{display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border);font-size:.86rem}}
.ph-item input[type=checkbox]{{accent-color:var(--accent);width:16px;height:16px}}
.ph-item label{{cursor:pointer}}

/* Footer */
.footer{{margin-top:36px;padding-top:14px;border-top:1px solid var(--border);color:var(--text2);font-size:.76rem;text-align:center}}

/* Print */
@media print{{
    .tabs,.tab-btn,.hdr,.meta,.footer,.res-actions,.ph-list{{display:none!important}}
    body{{background:#fff;color:#000;padding:0;font-size:11pt}}
    .tab-panel{{display:block!important}}
    #tab-resume{{display:block!important}}
    #tab-analysis{{display:none!important}}
    .res-container{{background:#fff;border:none;padding:0;max-width:100%}}
    .res-h1{{color:#000}}
    .res-h2{{color:#333;border-bottom-color:#333}}
    .res-h3{{color:#222}}
    .res-container p,.res-container li{{color:#000}}
    .placeholder{{background:#fff3cd;color:#856404;border-color:#856404}}
}}

@media(max-width:680px){{
    .sc-row{{grid-template-columns:1fr;gap:3px}}
    .ats-row{{grid-template-columns:28px 1fr}}
    .ats-detail{{grid-column:1/-1;padding-left:36px}}
    .hdr{{flex-direction:column;align-items:center;text-align:center}}
    .act-item{{flex-direction:column}}
    .res-container{{padding:20px 16px}}
    .tab-btn{{padding:10px 16px;font-size:.84rem}}
}}
</style>
</head>
<body>
<div class="wrap">

<!-- HEADER -->
<div class="hdr">
    <div class="hdr-info">
        <h1>Resume Analysis Report</h1>
        <div class="sub">{esc(d.get("candidate_name", "Candidate"))} · {esc(date)}</div>
    </div>
    <div>
        <div class="grade-ring">{grade}<span class="gs">GRADE</span></div>
        <div class="overall-num">{d["overall_score"]}/100</div>
    </div>
</div>

<!-- META -->
<div class="meta">
    <div class="meta-item"><strong>Words:</strong> {meta.get("word_count", "—")}</div>
    <div class="meta-item"><strong>Pages:</strong> {meta.get("page_count", "—")}</div>
    <div class="meta-item"><strong>Format:</strong> {meta.get("file_type", "—").upper()}</div>
    {target_html}
</div>

<!-- TABS -->
<div class="tabs">
    <button class="tab-btn active" onclick="switchTab('analysis')">📊 Analysis</button>
    <button class="tab-btn" onclick="switchTab('resume')">📄 Revised Resume</button>
</div>

<!-- ==================== TAB 1: ANALYSIS ==================== -->
<div class="tab-panel active" id="tab-analysis">

<h2>Score Breakdown</h2>
<div class="radar-wrap">{radar_svg}</div>
{scores_html}

<h2>Section-by-Section Analysis</h2>
<p style="color:var(--text2);font-size:.82rem;margin-bottom:10px">Click to expand each section.</p>
{sections_html}

{ats_html}

<h2>Priority Action Plan</h2>
<p style="color:var(--text2);font-size:.82rem;margin-bottom:10px">Top changes ranked by interview impact.</p>
{actions_html}

</div>

<!-- ==================== TAB 2: REVISED RESUME ==================== -->
<div class="tab-panel" id="tab-resume">

<div class="res-actions">
    <button class="btn btn-primary" onclick="copyResume()">📋 Copy Resume Text</button>
    <button class="btn btn-secondary" onclick="window.print()">🖨️ Print Resume</button>
    <span class="copy-ok" id="copy-ok">✓ Copied!</span>
</div>

<div class="res-container">
{revised_rendered}
</div>

{placeholders_html}

</div>

<div class="footer">Generated by Intensive Resume Analyser · {esc(date)}</div>

</div>

<script>
function switchTab(t) {{
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    if (t === 'analysis') {{
        document.querySelectorAll('.tab-btn')[0].classList.add('active');
        document.getElementById('tab-analysis').classList.add('active');
    }} else {{
        document.querySelectorAll('.tab-btn')[1].classList.add('active');
        document.getElementById('tab-resume').classList.add('active');
    }}
}}

const resumeMD = `{revised_for_js}`;

function copyResume() {{
    navigator.clipboard.writeText(resumeMD).then(() => {{
        const ok = document.getElementById('copy-ok');
        ok.style.display = 'inline';
        setTimeout(() => ok.style.display = 'none', 2000);
    }}).catch(() => {{
        // Fallback
        const ta = document.createElement('textarea');
        ta.value = resumeMD;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        const ok = document.getElementById('copy-ok');
        ok.style.display = 'inline';
        setTimeout(() => ok.style.display = 'none', 2000);
    }});
}}
</script>
</body>
</html>'''


def main():
    if len(sys.argv) < 3:
        print("Usage: python generate_report.py <analysis.json> <output.html>")
        sys.exit(1)
    with open(sys.argv[1]) as f:
        data = json.load(f)
    html = generate_html(data)
    with open(sys.argv[2], "w") as f:
        f.write(html)
    print(f"Report saved to {sys.argv[2]}")


if __name__ == "__main__":
    main()


"""
FULL DATA STRUCTURE REFERENCE:

{
    "candidate_name": "Name",
    "analysis_date": "April 1, 2026",
    "overall_score": 72,          # 0–100 weighted
    "scores": {
        "impact_achievements":      {"score": 7, "weight": 20, "label": "Impact & Achievements", "summary": "..."},
        "ats_compatibility":        {"score": 6, "weight": 15, "label": "ATS Compatibility", "summary": "..."},
        "content_relevance":        {"score": 8, "weight": 12, "label": "Content Relevance", "summary": "..."},
        "structure_flow":           {"score": 7, "weight": 10, "label": "Structure & Flow", "summary": "..."},
        "formatting_readability":   {"score": 6, "weight": 10, "label": "Formatting & Readability", "summary": "..."},
        "language_grammar":         {"score": 8, "weight": 8,  "label": "Language & Grammar", "summary": "..."},
        "skills_presentation":      {"score": 5, "weight": 8,  "label": "Skills Presentation", "summary": "..."},
        "career_narrative":         {"score": 7, "weight": 7,  "label": "Career Narrative", "summary": "..."},
        "digital_presence":         {"score": 4, "weight": 5,  "label": "Digital Presence", "summary": "..."},
        "compliance_red_flags":     {"score": 8, "weight": 5,  "label": "Compliance & Red Flags", "summary": "..."}
    },
    "sections": [
        {
            "name": "Section Name",
            "status": "present|missing|needs_improvement",
            "strengths": ["..."],
            "issues": [{"severity": "critical|important|minor", "text": "..."}],
            "rewrites": [{"before": "...", "after": "...", "why": "..."}]
        }
    ],
    "ats_audit": {
        "overall": "pass|warning|fail",
        "checks": [{"item": "...", "status": "pass|fail|warning", "detail": "..."}],
        "keyword_analysis": {
            "found": ["..."],
            "missing": ["..."],
            "match_rate": 65
        }
    },
    "priority_actions": [
        {"rank": 1, "action": "...", "impact": "high|medium", "effort": "low|medium|high"}
    ],
    "revised_resume_md": "# FULL NAME\\nemail | phone | city\\n\\n## Professional Summary\\n...",
    "meta": {
        "word_count": 450,
        "page_count": 1,
        "file_type": "pdf",
        "target_role": "..."
    }
}
"""
