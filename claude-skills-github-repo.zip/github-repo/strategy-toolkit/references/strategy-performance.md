# Turning Great Strategy into Great Performance

Source: Michael C. Mankins and Richard Steele, Harvard Business Review

## Core Concept

Most companies' strategies deliver only 63% of their promised financial value. This strategy-to-performance gap is caused by a combination of poor planning, fuzzy accountability, inadequate resources, and broken feedback loops. Companies often misdiagnose the problem: they push for better execution when they really need a sounder strategy, or they craft a new strategy when execution is the true weak spot.

## The Seven Rules

### Rule 1: Keep It Simple, Make It Concrete
Avoid drawn-out, jargon-filled descriptions of strategic goals. Instead, clearly describe what the company will and will not do. If you cannot explain your strategy in plain language that every employee understands, it is not clear enough to execute.

### Rule 2: Debate Assumptions, Not Forecasts
Strategic planning often degenerates into negotiated settlements where business units haggle over forecast numbers. Instead, surface and debate the KEY ASSUMPTIONS underlying each strategy. What must be true about the market, customers, and competition for this strategy to work? If those assumptions are wrong, the forecast is meaningless regardless of the number.

### Rule 3: Use a Rigorous Framework, Speak a Common Language
Every business unit should use the same strategic framework and terminology when presenting plans to corporate. Without a common language, strategic reviews become superficial because corporate leaders cannot compare across units or challenge assumptions meaningfully.

### Rule 4: Discuss Resource Deployments Early
Too many strategic plans defer resource allocation to the budgeting process, creating a disconnect. Discuss the resource implications of each strategic choice during strategic planning, not after. Front-load the hard resource trade-offs.

### Rule 5: Clearly Identify Priorities
A strategy with 20 priorities has no priorities. Limit strategic initiatives to 3-5 per business unit. Specify what will receive resources and, critically, what will NOT.

### Rule 6: Continuously Monitor Performance
Do not wait for the annual strategic review to check whether the strategy is on track. Implement continuous monitoring with early warning indicators. When performance deviates from plan, diagnose whether the problem is the strategy or the execution.

### Rule 7: Reward and Develop Execution Capabilities
Close the loop between strategy and accountability. People who deliver on strategic commitments should be visibly rewarded. Invest in building execution capabilities, not just strategic planning capabilities.

## The Performance Gap Diagnostic

When a strategy is underperforming, ask these questions in order:

1. **Is the strategy clear?** Can every manager articulate it in plain language?
2. **Are assumptions valid?** Which key assumptions have changed since the strategy was set?
3. **Are resources adequate?** Were the right resources allocated? Were they actually deployed?
4. **Is accountability clear?** Does every strategic initiative have a single owner with clear milestones?
5. **Is monitoring happening?** Are deviations being detected early enough to course-correct?
6. **Is it a strategy problem or an execution problem?** (This is the critical diagnostic question. Getting it wrong leads to wasted effort.)

## Closing the Gap: The Execution Premium

Companies that close the strategy-to-performance gap share these habits:
- Strategic planning and budgeting are integrated (not sequential, disconnected processes)
- Assumptions are explicitly stated and tracked
- Resource allocation is debated during strategy, not during budgeting
- Performance reviews happen continuously, not annually
- Failures are diagnosed honestly (strategy failure vs execution failure vs assumption failure)

## Application Methodology

1. **Assess the gap** - What was the strategic plan's promised value? What was actually delivered? What is the percentage gap?
2. **Run the diagnostic** - Walk through the six questions above to pinpoint root causes
3. **Apply the seven rules** to redesign the strategic planning and execution process
4. **Set up monitoring** - Define 5-7 leading indicators that signal whether the strategy is on track before financial results come in

## Common Pitfalls

- Responding to poor results by creating a new strategy when the existing strategy was never properly executed
- Responding to poor execution by pushing harder on the same plan when the strategy itself is flawed
- Annual strategic planning as a ritual rather than a rigorous decision-making process
- Too many priorities diluting resources and focus
