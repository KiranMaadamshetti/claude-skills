# Transforming Corner-Office Strategy into Frontline Action

Source: Orit Gadiesh and James L. Gilbert, Harvard Business Review

## Core Concept

The gap between strategy formulation and frontline execution exists because employees cannot remember or act on 50-page strategic plans. The solution is a Strategic Principle: a memorable, actionable phrase that distills the essence of your company's strategy so that frontline employees can make the right decisions without escalating everything.

## What Makes a Powerful Strategic Principle

A strategic principle must pass three tests:

### 1. It Must Be Specific to Your Company
Generic principles like "customer first" or "quality matters" are useless because they apply to any company. The principle must clearly favor one course of action over another in contested decisions.

**Test:** If your competitor could adopt the same principle without contradiction, it is not specific enough.

### 2. It Must Be Actionable
An employee facing a real-time decision should be able to use it as a decision filter. It should tell them what to do (or not do) without requiring further interpretation.

### 3. It Must Be Memorable
If employees cannot recall it in the moment of decision, it might as well not exist. One phrase. No jargon. No abstractions.

## Examples of Strong Strategic Principles

- **Southwest Airlines:** "Meet customers' short-haul travel needs at fares competitive with the cost of automobile travel." This tells every employee the priority: low cost, short routes, compete with cars (not other airlines).
- **Dell (early days):** "Be direct." Two words that guided every decision about channels, customer relationships, inventory.
- **eBay:** "Focus on trading communities." Every product decision filtered through whether it served the community of traders.

## Creating Your Strategic Principle

### Step 1: Examine Your Strategy
What is the fundamental strategic choice your company has made? What trade-offs define you? What do you do that competitors do not?

### Step 2: Identify the Core Trade-off
Every strategy involves choosing one thing over another. The principle should capture this trade-off. Southwest chose low cost and convenience over full service and hub-and-spoke networks.

### Step 3: Draft the Principle
Condense the strategy into one phrase that:
- Makes the trade-off explicit
- Provides decision-making guidance
- Is unique to your company
- Is memorable enough to repeat in a meeting

### Step 4: Stress-Test It
Take 5-10 real decisions the company has faced recently. Apply the principle. Does it consistently point to the right answer? Does it help resolve debates?

### Step 5: Communicate Relentlessly
Once established, the principle must be communicated repeatedly through every channel. Leaders must reference it in every major decision to model its use.

## Application Methodology

When helping a user create a strategic principle:
1. First ensure they have a clear strategy (use Porter's Strategy framework if needed)
2. Identify the core trade-offs their strategy embodies
3. Draft 3-5 candidate principles
4. Test each against recent real decisions
5. Select the one that most consistently guides the right choice
6. Refine for memorability and clarity

## Common Pitfalls

- Confusing a strategic principle with a mission statement (a principle is a decision rule, a mission is an aspiration)
- Making it too generic (if any company could adopt it, it is not a strategic principle)
- Making it too long or complex (if employees cannot recall it, it fails)
- Creating the principle before having a clear strategy (a principle codifies strategy, it does not create it)
