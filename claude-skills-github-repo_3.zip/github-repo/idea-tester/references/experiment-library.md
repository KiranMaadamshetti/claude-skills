# Experiment Library

44 experiments organized by phase (Discovery vs Validation) and type. Each entry includes what it tests, cost level, evidence strength, and when to use it.

## DISCOVERY EXPERIMENTS

Discovery experiments are cheap and fast. They help you discover if your general direction is right. Use these BEFORE building anything.

### Exploration Experiments (Talk to People)

| # | Experiment | Tests | Cost | Evidence | When to Use |
|---|-----------|-------|------|----------|-------------|
| 1 | **Customer Interview** | Desirability | Low | Weak-Moderate | First experiment for any new idea. Explore jobs, pains, gains, willingness to pay. 15-20 interviews minimum. |
| 2 | **Expert Stakeholder Interview** | Desirability, Feasibility | Low | Weak | Talk to industry experts, analysts, domain authorities to validate market assumptions. |
| 3 | **Partner and Supplier Interview** | Feasibility, Viability | Low | Weak-Moderate | Talk to potential partners, suppliers, distributors to validate operational hypotheses. |
| 4 | **A Day in the Life** | Desirability | Low-Medium | Moderate | Shadow customers in their natural environment to observe real behavior, not stated preferences. |
| 5 | **Discovery Survey** | Desirability | Low | Weak-Moderate | Quantitative survey to validate patterns found in interviews. Use AFTER interviews, not instead of. |

### Data Analysis Experiments (Look at Existing Data)

| # | Experiment | Tests | Cost | Evidence | When to Use |
|---|-----------|-------|------|----------|-------------|
| 6 | **Search Trend Analysis** | Desirability | Free | Moderate | Use Google Trends, keyword tools to check if people are searching for solutions to the problem you solve. |
| 7 | **Web Traffic Analysis** | Desirability | Free-Low | Moderate | Analyse existing website/app data for behavior patterns. Works if you have an existing product. |
| 8 | **Discussion Forums** | Desirability | Free | Weak-Moderate | Browse Reddit, Quora, niche forums for unmet needs, complaints, and pain points. |
| 9 | **Sales Force Feedback** | Desirability, Viability | Free | Moderate | Collect insights from your sales team about customer objections, requests, and lost deals. |
| 10 | **Customer Support Analysis** | Desirability | Free | Moderate | Analyse support tickets, complaints, and feature requests for patterns. |

### Interest Discovery Experiments (Measure Interest Without Building)

| # | Experiment | Tests | Cost | Evidence | When to Use |
|---|-----------|-------|------|----------|-------------|
| 11 | **Online Ad** | Desirability | Low-Medium | Moderate | Run targeted ads (Google, Facebook, Instagram) to measure click-through rates on your value proposition. |
| 12 | **Link Tracking** | Desirability | Low | Moderate | Place trackable links in emails, social posts, or content to measure interest in specific offerings. |
| 13 | **404 Test / Fake Door** | Desirability | Low | Moderate-Strong | Add a button or link for a feature that does not exist yet. Measure clicks. High clicks = demand signal. |
| 14 | **Feature Stub** | Desirability | Low | Moderate | Add a teaser for an upcoming feature in your existing product. Measure interest (clicks, sign-ups). |
| 15 | **Email Campaign** | Desirability | Low | Moderate | Send targeted emails describing your value proposition. Measure open rates, click rates, replies. |
| 16 | **Social Media Campaign** | Desirability | Low | Moderate | Post about the problem you solve on social media. Measure engagement, DMs, shares, comments. |
| 17 | **Referral Program** | Desirability, Viability | Low-Medium | Moderate-Strong | Test if existing users/contacts will refer others. High referral = strong product-market fit signal. |

### Discussion Prototype Experiments (Show, Do Not Tell)

| # | Experiment | Tests | Cost | Evidence | When to Use |
|---|-----------|-------|------|----------|-------------|
| 18 | **3D Print Prototype** | Desirability, Feasibility | Low-Medium | Moderate | For physical products: print a rough model to show customers. Test form factor and concept. |
| 19 | **Paper Prototype** | Desirability | Low | Weak-Moderate | Sketch screens on paper, walk customers through the flow. Test usability and concept before building. |
| 20 | **Storyboard** | Desirability | Low | Weak | Draw a comic-strip story of the customer using your solution. Test if the narrative resonates. |
| 21 | **Data Sheet** | Desirability, Viability | Low | Weak-Moderate | Create a one-page spec sheet for B2B products. Test if the features and pricing generate interest. |
| 22 | **Brochure** | Desirability | Low | Weak-Moderate | Create a marketing brochure for a product that does not exist yet. Measure reactions and interest. |
| 23 | **Boomerang** | Desirability | Low | Moderate | Send customers an unfinished idea or concept to get feedback that "boomerangs" back with insights. |
| 24 | **Explainer Video** | Desirability | Low-Medium | Moderate | Create a short video explaining your value proposition. Measure views, shares, sign-ups. |
| 25 | **Product Box** | Desirability | Low | Moderate | Have customers design the box for your product (what features would they put on it?). Reveals priorities. |
| 26 | **Speed Boat** | Desirability | Low | Moderate | Visual game: draw a speed boat, have customers add "anchors" (what slows them down). Reveals pain points. |
| 27 | **Card Sorting** | Desirability | Low | Moderate | Give customers cards with jobs/pains/gains. Have them sort and rank. Reveals true priorities. |
| 28 | **Buy a Feature** | Desirability, Viability | Low | Moderate-Strong | Give customers fake currency to "buy" features. Forces trade-offs and reveals what they truly value. |

---

## VALIDATION EXPERIMENTS

Validation experiments generate stronger evidence but cost more and take longer. Use these AFTER discovery experiments have confirmed your general direction.

### Prototype Experiments (Build Something Minimal)

| # | Experiment | Tests | Cost | Evidence | When to Use |
|---|-----------|-------|------|----------|-------------|
| 29 | **Clickable Prototype** | Desirability, Feasibility | Medium | Moderate-Strong | Interactive mockup (Figma, InVision). Test usability and engagement without real code. |
| 30 | **Single Feature MVP** | Desirability, Feasibility | Medium-High | Strong | Build ONE core feature only. Test if that single feature delivers enough value. |
| 31 | **Mash-Up MVP** | Desirability, Feasibility | Medium | Moderate-Strong | Combine existing tools and services (Zapier, no-code) to simulate your product. |
| 32 | **Concierge** | Desirability, Viability | Medium | Strong | Deliver the value proposition manually, person-by-person. Test willingness to pay and actual value. |
| 33 | **Wizard of Oz** | Desirability | Medium | Strong | Product appears automated to the customer, but is actually done manually behind the scenes. |
| 34 | **Life-Size Prototype** | Desirability, Feasibility | Medium-High | Strong | Full-scale physical model of your product. Test form factor, ergonomics, customer reactions. |

### Call to Action Experiments (Ask for Real Commitment)

| # | Experiment | Tests | Cost | Evidence | When to Use |
|---|-----------|-------|------|----------|-------------|
| 35 | **Landing Page / Smoke Test** | Desirability | Low-Medium | Moderate-Strong | Landing page with value prop + call-to-action (sign up, pre-order). Measure conversion rate. |
| 36 | **Presale** | Desirability, Viability | Medium | Very Strong | Sell the product before it exists. Actual payment = strongest evidence of demand. |
| 37 | **Crowdfunding** | Desirability, Viability | Medium | Very Strong | Launch on Kickstarter, Indiegogo, or equivalent. Funding = validated demand at scale. |
| 38 | **Split Test / A-B Test** | Desirability | Low-Medium | Strong | Test two versions of a page, feature, or offer. Measure which performs better with statistical significance. |
| 39 | **Letter of Intent** | Viability | Low | Strong | For B2B: get potential customers to sign a non-binding letter of intent to purchase. Strong demand signal. |
| 40 | **Mock Sale** | Desirability, Viability | Medium | Very Strong | Simulate the complete sales process. Customer goes through checkout but is told product is not ready yet. |

### Advanced Validation Experiments

| # | Experiment | Tests | Cost | Evidence | When to Use |
|---|-----------|-------|------|----------|-------------|
| 41 | **Pop-Up Store** | Desirability, Viability | Medium-High | Very Strong | Temporary physical presence to test retail demand, pricing, and customer experience. |
| 42 | **Extreme Programming Spike** | Feasibility | Medium | Strong | Short, time-boxed technical investigation to test if a critical technology component is feasible. |
| 43 | **Simulated Sale via Telemarketing** | Desirability, Viability | Low-Medium | Strong | Call potential customers and pitch. Track conversion through the full sales funnel. |
| 44 | **Pre-Order with Deposit** | Viability | Medium | Very Strong | Take deposits or pre-orders with partial payment. Money down = maximum evidence of demand. |

---

## Experiment Selection Decision Tree

```
START
  |
  v
Do you have ANY evidence yet?
  |
  NO --> Run DISCOVERY experiments first
  |        |
  |        v
  |      What type of hypothesis?
  |        |
  |      Desirability --> Customer Interviews + Online Ad + Survey
  |      Feasibility --> Expert Interviews + Partner Interviews
  |      Viability --> Sales Force Feedback + Data Sheet + Buy a Feature
  |
  YES --> Is evidence strong enough to decide?
           |
           NO --> Run VALIDATION experiments
           |       |
           |       v
           |     What type of hypothesis?
           |       |
           |     Desirability --> Landing Page + Presale + Concierge
           |     Feasibility --> Single Feature MVP + Spike + Wizard of Oz
           |     Viability --> Mock Sale + Presale + Crowdfunding + LOI
           |
           YES --> DECIDE (Persevere / Pivot / Kill)
```

## Evidence Strength by Experiment

From weakest to strongest:

1. **Opinions** - Interviews, surveys (what people SAY)
2. **Interest signals** - Ad clicks, page views, email opens
3. **Engagement** - Sign-ups, time on site, feature usage
4. **Behavioral commitment** - Account creation, profile completion
5. **Financial commitment** - Pre-order, deposit, purchase, crowdfunding pledge
6. **Repeated behavior** - Repeat purchase, renewal, referral with effort
