# Strategy Toolkit — Claude Skill

**10 proven strategic frameworks for business analysis, competitive positioning, and strategy execution.**

## Quick Install

1. Download [`strategy-toolkit.skill`](strategy-toolkit.skill)
2. Go to [claude.ai](https://claude.ai) → Settings → Profile → Skills → Add Skill
3. Upload the file
4. Ask any strategy question — Claude automatically picks the right framework

## The 10 Frameworks

### Strategy Development
| # | Framework | Use When |
|---|-----------|----------|
| 1 | **Porter's What Is Strategy** | Defining your unique position, trade-offs, and activity system |
| 2 | **Five Competitive Forces** | Assessing industry attractiveness and profit potential |
| 3 | **Blue Ocean Strategy** | Finding uncontested market space beyond bloody competition |
| 4 | **Building Company Vision** | Defining core values, purpose, and a 10-30 year BHAG |
| 5 | **Business Model Reinvention** | Designing how you create and capture value |

### Strategy Execution
| # | Framework | Use When |
|---|-----------|----------|
| 6 | **Strategy Execution** | Fixing decision rights and information flow |
| 7 | **Balanced Scorecard** | Measuring progress across financial, customer, process, learning |
| 8 | **Strategic Principles** | Distilling strategy into one actionable phrase for frontline |
| 9 | **Strategy-to-Performance Gap** | Closing the gap where companies lose 37% of strategic value |
| 10 | **RAPID Decision Model** | Clarifying who Recommends, Agrees, Performs, Inputs, Decides |

## Example Prompts

### Basic
```
Help me build a competitive strategy for my business
```

### Industry Analysis
```
Do a Five Forces analysis for the [your industry] in [your market]
```

### Finding New Markets
```
My market is crowded and commoditized. Use the Blue Ocean
Four Actions Framework to help me find differentiated positioning.
```

### Fixing Execution
```
Our strategy is clear but execution is failing.
Diagnose using decision rights and information flow frameworks.
```

### Full Strategic Planning
```
I run [company description]. Our core challenge is [problem].
Do a full strategic analysis using the most relevant frameworks
and give me actionable recommendations with trade-offs.
```

### Decision Clarity
```
These 3 decisions keep getting stuck in our org:
1. [Decision A]
2. [Decision B]
3. [Decision C]
Map each using the RAPID framework.
```

## How Claude Selects Frameworks

You do not need to name frameworks. Just describe your problem:

| You Say | Claude Uses |
|---------|------------|
| "How should we compete?" | Porter's Strategy + Five Forces |
| "This market is too crowded" | Blue Ocean + Business Model |
| "What should our company stand for?" | Vision Framework |
| "Strategy exists but results are not coming" | Execution + Seven Rules |
| "I need to measure strategic progress" | Balanced Scorecard |
| "Decisions are stuck and slow" | RAPID Decision Model |
| "Should we enter this market?" | Five Forces + Blue Ocean + Business Model |

## Skill Contents

| File | Purpose |
|------|---------|
| `SKILL.md` | Core instructions — workflow, framework selection matrix, emerging market adaptations |
| `references/framework-selector.md` | Decision guide for choosing the right framework(s) |
| `references/porter-strategy.md` | Strategic positioning, trade-offs, activity fit |
| `references/five-forces.md` | Industry analysis — all 5 forces with scoring template |
| `references/blue-ocean.md` | ERRC grid, Six Paths, three tiers of non-customers |
| `references/vision-framework.md` | Core ideology, BHAG types, vivid description |
| `references/business-model.md` | CVP, profit formula, key resources, key processes |
| `references/strategy-execution.md` | Four building blocks — decision rights first |
| `references/balanced-scorecard.md` | Four perspectives, four management processes |
| `references/strategic-principles.md` | One-phrase strategy creation methodology |
| `references/strategy-performance.md` | Seven rules for closing the performance gap |
| `references/rapid-decisions.md` | RAPID role assignment with templates |

## Pro Tips

1. **Give context** — The more Claude knows about your business, the sharper the analysis
2. **Provide numbers** — Even rough revenue, market share, team size data helps enormously
3. **Ask for trade-offs** — "What should I stop doing?" is as valuable as "What should I start?"
4. **Layer frameworks** — "Do Five Forces first, then use it to define our positioning"
5. **Test against real decisions** — "Given this strategy, should we expand to City A or City B first?"
