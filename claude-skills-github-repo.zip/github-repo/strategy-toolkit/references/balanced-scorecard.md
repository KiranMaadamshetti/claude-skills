# Using the Balanced Scorecard as a Strategic Management System

Source: Robert S. Kaplan and David P. Norton, Harvard Business Review

## Core Concept

Traditional financial measures tell you what happened in the past but are poor guides for creating future value. The Balanced Scorecard supplements financial measures with three additional perspectives that together provide a comprehensive view of strategic performance.

The Scorecard is NOT just a measurement system. It is a strategic MANAGEMENT system that uses measurement to drive strategy execution.

## The Four Perspectives

### 1. Financial Perspective
"How do we look to shareholders?"
- Revenue growth, profitability, return on capital, cash flow
- These are the ultimate outcome measures. If the strategy works, financial results follow.

### 2. Customer Perspective
"How do customers see us?"
- Customer satisfaction, retention, acquisition, market share
- Customer value proposition: what combination of product, price, service, and relationship do we offer?

### 3. Internal Business Process Perspective
"What must we excel at?"
- The critical internal processes where the organization must excel to deliver the customer value proposition
- Innovation processes, operations processes, post-sale service processes

### 4. Learning and Growth Perspective
"Can we continue to improve and create value?"
- Employee capabilities, information systems capabilities, motivation and empowerment
- This is the foundation. Without learning and growth, internal processes stagnate.

## The Four Management Processes

The Scorecard drives strategy through four linked processes:

### Process 1: Translating the Vision
Convert strategy from abstract vision into specific objectives and measures that people can act on. Forces management to build consensus on what the strategy actually means in operational terms.

### Process 2: Communicating and Linking
Communicate strategy throughout the organization and link it to departmental and individual objectives. Everyone should understand how their daily work connects to strategic goals.

### Process 3: Business Planning
Integrate strategic plans with financial budgets. Set targets (3-5 year stretch goals) and milestones (what must be achieved this quarter/year). Allocate resources to strategic initiatives, not just business-as-usual.

### Process 4: Feedback and Learning
Provide strategic feedback and learning. Test whether the strategy is working using cause-and-effect relationships: Did investment in employee training (learning) improve process quality (internal)? Did process quality improve customer satisfaction (customer)? Did satisfaction improve financial results (financial)?

## Application Methodology

1. **Clarify the strategy** - Before building a scorecard, ensure strategy is well-defined (use Porter's strategy or another framework first if needed)
2. **Select 15-25 measures** across the four perspectives (3-7 per perspective)
3. **Build cause-and-effect hypotheses** - How does improvement in learning drive internal process improvement, which drives customer value, which drives financial results?
4. **Set targets** for each measure (both short-term milestones and long-term goals)
5. **Identify strategic initiatives** needed to achieve targets
6. **Review and learn** - Use the scorecard in regular management reviews (monthly/quarterly)

## Scorecard Template

| Perspective | Objective | Measure | Target | Initiative |
|---|---|---|---|---|
| Financial | [What financial outcome?] | [How measured?] | [Target value] | [What to do?] |
| Customer | [What customer outcome?] | [How measured?] | [Target value] | [What to do?] |
| Internal Process | [What process to improve?] | [How measured?] | [Target value] | [What to do?] |
| Learning and Growth | [What capability to build?] | [How measured?] | [Target value] | [What to do?] |

## Common Pitfalls

- Treating the scorecard as a KPI dashboard rather than a strategic management system
- Too many measures (more than 25 dilutes focus)
- Missing the cause-and-effect linkages between perspectives
- Using the scorecard for operational monitoring instead of strategic learning
- Building a scorecard without first having a clear strategy (a scorecard does not create strategy, it implements it)
- Financial measures dominating the conversations while the other three perspectives are neglected
