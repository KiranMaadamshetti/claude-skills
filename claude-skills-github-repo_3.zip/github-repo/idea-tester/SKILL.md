---
name: idea-tester
description: >-
  Business idea testing and validation toolkit with 44 experiments.
  Use this skill when a user wants to test, validate, or de-risk a
  business idea, startup concept, new product, or feature. Triggers
  include test my idea, validate my business idea, how do I know if
  my idea will work, experiment design, MVP testing, customer
  validation, should I build this, de-risk my startup, assumptions
  mapping, test card, lean startup, how to test before building,
  market validation, idea validation, desirability testing,
  feasibility testing, viability testing, presale test, smoke test,
  fake door test, landing page test, or any request about reducing
  risk and uncertainty before investing heavily in an idea.
---

# Business Idea Tester

A systematic toolkit for testing business ideas through rapid experimentation. Helps users reduce risk by running the right experiments before committing significant time and money. Based on 44 proven experiments organized by discovery and validation phases.

## Core Philosophy

**Do not build it until you have tested it.** Most ideas fail not because the product is bad, but because the business model is wrong. Testing is the activity of reducing risk before you invest heavily. You test ideas by running rapid experiments that generate real evidence, not opinions.

## When This Skill Activates

- User has a business idea and wants to know if it will work
- User wants to validate demand before building
- User needs to design experiments for their startup
- User wants to prioritize what to test first
- User is stuck between multiple ideas and needs a testing framework
- User has built something and it is not working (needs to diagnose why)
- User asks about MVP, lean startup, customer validation, or smoke tests

## Core Workflow

```
1. SHAPE    -> Understand the idea using Business Model Canvas / Value Proposition Canvas
2. HYPOTHESIZE -> Extract and prioritize risky assumptions (Assumptions Map)
3. EXPERIMENT  -> Select right experiments from the 44-experiment library
4. LEARN    -> Analyse evidence, extract insights (Learning Card)
5. DECIDE   -> Persevere, Pivot, or Kill based on evidence
```

Read `references/testing-process.md` for the detailed methodology of each step.

## Step 1: SHAPE the Idea

Before testing, the idea must be articulated clearly. Help the user map their idea across two canvases:

**Value Proposition Canvas:**
- Customer Segment: Who is the customer?
- Customer Jobs: What are they trying to get done?
- Pains: What frustrates them about current solutions?
- Gains: What would delight them?
- Products and Services: What are you offering?
- Pain Relievers: How do you address their pains?
- Gain Creators: How do you create gains?

**Business Model Canvas (9 blocks):**
- Customer Segments, Value Proposition, Channels, Customer Relationships, Revenue Streams, Key Resources, Key Activities, Key Partnerships, Cost Structure

If the user cannot clearly articulate these, help them think through it. This is the foundation for everything else.

## Step 2: HYPOTHESIZE

Extract all assumptions and turn them into testable hypotheses across three risk types:

**Desirability Risk** (Will customers want this?)
- Do customers have the jobs, pains, and gains we think they have?
- Will they choose our solution over alternatives?
- Are they willing to pay what we need to charge?

**Viability Risk** (Can we make money doing this?)
- Can we generate sufficient revenue?
- Is the cost structure sustainable?
- Will the unit economics work?

**Feasibility Risk** (Can we actually build and deliver this?)
- Do we have the technology and capabilities?
- Can we source key resources and partnerships?
- Can we scale operations?

Use the **Assumptions Map** to prioritize: plot each hypothesis on a 2x2 grid of Importance (y-axis) vs Evidence (x-axis). The top-right quadrant (important + no evidence) is where you start testing.

**Hypothesis format:** "We believe that [specific, testable claim about customers/market/business]"

Read `references/testing-process.md` for detailed hypothesis creation guidance.

## Step 3: EXPERIMENT

Select experiments from the library based on:
1. **Type of hypothesis** (desirability, viability, or feasibility)
2. **Stage** (discovery = early/cheap/fast, validation = later/stronger evidence)
3. **Evidence strength needed** (weak opinions vs strong behavioral evidence)
4. **Time and budget available**

Read `references/experiment-library.md` for the complete 44-experiment catalog organized by category with cost, time, and evidence strength ratings.

**Key principle: Start cheap and fast, then increase fidelity.**

Discovery experiments (interviews, surveys, ads, landing pages) generate weak-to-moderate evidence cheaply. Validation experiments (presales, concierge, MVPs, crowdfunding) generate strong evidence but cost more. Always run discovery first.

### Experiment Selection Rules

1. Start with discovery experiments before validation
2. Reduce uncertainty as much as possible before building anything
3. Run multiple experiments per hypothesis (one experiment is never enough)
4. Match evidence strength to the stakes of your decision
5. Use experiment sequences (read `references/experiment-sequences.md`)

## Step 4: LEARN

After each experiment, use the **Learning Card**:
1. **Analyse the evidence** - Distinguish strong evidence (actual behavior, purchases) from weak evidence (opinions, stated preferences)
2. **Extract insights** - What did you learn that changes your understanding?
3. **Assess confidence** - How confident are you now? Consider: type of evidence, number of data points, and whether multiple experiments point to the same conclusion

**Evidence strength hierarchy (weak to strong):**
- Opinions and stated preferences ("I would buy this")
- Interest signals (clicks, sign-ups, email opt-ins)
- Behavioral commitment (time spent, tasks completed)
- Financial commitment (pre-orders, deposits, purchases)

## Step 5: DECIDE

Based on evidence and insights, make one of three decisions:

**Persevere** - Evidence supports your hypothesis. Move to the next important hypothesis, or run a stronger experiment on the same one.

**Pivot** - Evidence partially refutes your hypothesis. Change one or more elements of your value proposition or business model while keeping what works.

**Kill** - Evidence strongly refutes your hypothesis and no viable pivot exists. Stop investing in this idea. Killing bad ideas early is a superpower.

**If evidence is unclear:** Run more experiments. Do not make major decisions on ambiguous data.

## How to Help Users

### When user says "I have an idea"
1. Help them shape it (Value Proposition Canvas + Business Model Canvas)
2. Extract hypotheses across all three risk types
3. Prioritize using Assumptions Map
4. Recommend first 2-3 experiments from the library
5. Design the Test Card for each experiment

### When user says "How do I validate this?"
1. Clarify what specifically they want to validate (desirability? viability? feasibility?)
2. Assess their stage (do they have any evidence yet, or starting from zero?)
3. Recommend experiments matched to their hypothesis type, budget, and timeline
4. Provide step-by-step experiment design

### When user says "Should I build this?"
1. Ask what evidence they have so far
2. If none: recommend discovery experiments first (do NOT say "yes, build it")
3. If some: assess evidence strength and recommend next steps
4. The answer is almost always "test more before building"

### When user has a specific experiment in mind
1. Help them design it properly (Test Card format)
2. Define success criteria BEFORE running
3. Suggest complementary experiments to pair with it
4. Warn about common pitfalls for that experiment type

## Output Formats

**For idea assessment:** Generate a structured analysis with the Business Model Canvas, Assumptions Map, prioritized hypotheses, and recommended experiment sequence.

**For experiment design:** Generate Test Cards with hypothesis, experiment type, metrics, and success criteria.

**For results analysis:** Generate Learning Cards with evidence analysis, insights, confidence level, and recommended next action (persevere/pivot/kill).

**For comprehensive testing plans:** Generate a full testing roadmap as an HTML report or document with phases, experiments, timelines, and decision gates.

## Adapting for Indian and Emerging Markets

- **Desirability testing in Tier 2-5 cities**: WhatsApp-based surveys and phone interviews often work better than online landing pages. Consider language barriers.
- **Viability testing**: Unit economics must account for lower price points, higher customer acquisition costs in fragmented markets, and regulatory compliance costs.
- **Feasibility in financial services**: RBI/NHB regulations, BC licensing, and partner bank requirements are critical feasibility hypotheses that must be tested early.
- **Low-cost experiments**: Use WhatsApp Business, Google Forms, and social media (especially YouTube and Instagram) for discovery experiments before investing in landing pages or prototypes.
- **Trust signals**: In relationship-driven markets, referral programs and partner channel experiments may generate stronger evidence than digital ads.
