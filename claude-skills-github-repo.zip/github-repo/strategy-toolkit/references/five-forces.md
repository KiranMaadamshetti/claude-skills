# Five Competitive Forces That Shape Strategy

Source: Michael E. Porter, Harvard Business Review

## Core Concept

Industry profitability is not a matter of luck or product aesthetics. It is determined by five competitive forces. Understanding these forces reveals the root causes of an industry's profitability and provides a framework for anticipating and influencing competition over time.

The job is not just to list the forces but to assess their STRENGTH and determine which ones are most critical to profitability in your specific industry.

## The Five Forces

### 1. Threat of New Entrants
New entrants bring new capacity and desire to gain market share, putting pressure on prices, costs, and investment. The threat depends on:

**Barriers to entry:**
- Supply-side economies of scale (incumbents produce at lower per-unit cost)
- Demand-side benefits of scale (network effects, buyer willingness to pay more for a product with more users)
- Customer switching costs
- Capital requirements
- Incumbency advantages independent of size (brand, proprietary tech, favorable locations, accumulated experience)
- Unequal access to distribution channels
- Restrictive government policy (licensing, regulations)

**Key question:** How easy is it for a new player to enter this industry and compete effectively?

### 2. Bargaining Power of Suppliers
Powerful suppliers capture more value by charging higher prices, limiting quality, or shifting costs. Suppliers are powerful when:
- The supplier group is more concentrated than the industry it sells to
- Suppliers do not depend heavily on this industry for revenue
- Industry players face switching costs in changing suppliers
- Suppliers offer differentiated products
- There is no substitute for what the supplier provides
- The supplier can credibly threaten to integrate forward

### 3. Bargaining Power of Buyers
Powerful buyers force prices down, demand better quality or service, and play competitors against each other. Buyers are powerful when:
- There are few buyers or each purchases in large volumes
- Products are standardized or undifferentiated
- Buyers face few switching costs
- Buyers can credibly threaten backward integration
- Buyer is price-sensitive (product is a significant cost, buyer earns low margins, quality of buyer's product is little affected)

### 4. Threat of Substitutes
A substitute performs the same or similar function as an industry's product by a different means. Substitutes limit profitability by placing a ceiling on prices. The threat is high when:
- The substitute offers an attractive price-performance trade-off
- The buyer's switching cost to the substitute is low

**Critical insight:** Substitutes are not just similar products. They are different products that solve the same customer need. Example: video conferencing is a substitute for air travel.

### 5. Rivalry Among Existing Competitors
Rivalry takes familiar forms: price discounting, new product launches, ad campaigns, service improvements. High rivalry limits profitability. Rivalry is most intense when:
- Competitors are numerous or roughly equal in size
- Industry growth is slow
- Exit barriers are high
- Rivals are highly committed to the business
- Firms cannot read each other's signals well
- Products or services lack differentiation
- Fixed costs are high relative to variable costs (creating pressure to fill capacity)

**Price competition is the most damaging form of rivalry.** It transfers profits directly to customers.

## Application Methodology

1. **Define the industry** precisely (not too broad, not too narrow)
2. **Assess each force** as high, medium, or low with specific evidence
3. **Identify the strongest 1-2 forces** that most constrain profitability
4. **Determine strategic implications** - position where forces are weakest, exploit changes in forces, or reshape forces in your favor
5. **Watch for changes** - forces shift over time due to technology, regulation, customer behavior

## Five Forces Scoring Template

For each force, rate 1-5 (1=weak force, favorable for industry; 5=strong force, threatens profitability):

- Threat of New Entrants: [1-5] because [evidence]
- Supplier Power: [1-5] because [evidence]
- Buyer Power: [1-5] because [evidence]
- Threat of Substitutes: [1-5] because [evidence]
- Competitive Rivalry: [1-5] because [evidence]
- **Overall Industry Attractiveness:** [Favorable / Moderate / Unfavorable]
- **Critical force(s):** The 1-2 forces most shaping profitability

## Common Pitfalls

- Confusing industry with a single company (forces apply to the INDUSTRY, not one firm)
- Defining the industry too broadly or narrowly
- Treating all forces as equally important (usually 1-2 dominate)
- Only looking at current state, not trajectory of forces
- Ignoring complements (products used together with yours that can influence demand)
- Forgetting that the goal is not to list forces but to use them to inform strategic positioning
