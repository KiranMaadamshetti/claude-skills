# RAPID Decision Model

Source: Paul Rogers and Marcia Blenko, Harvard Business Review

## Core Concept

Decisions are the coin of the realm in business. Every success, every failure, every opportunity seized or missed stems from a decision someone made or failed to make. Yet in many firms, decisions routinely stall inside the organization, hurting performance.

The root cause is almost always ambiguity about WHO has the right to make decisions, WHO provides input, and WHO is responsible for executing.

RAPID is a framework for assigning clear decision roles.

## The RAPID Roles

For every strategic decision, assign exactly these five roles:

### R - Recommend
Who is responsible for developing and proposing a course of action? The recommender:
- Gathers data, analyses options, and presents a recommendation
- Must have the analytical skills and information to make a good proposal
- May be one person or a small team
- Should have no more than 2-3 recommenders for any single decision

### A - Agree
Who must agree to the recommendation before it moves forward? The agree role is a veto, not just input. Use it sparingly:
- Should be reserved for decisions with legal, regulatory, or risk implications
- If too many people have agree roles, decisions stall
- A person with agree power who exercises the veto must work with the recommender to find a mutually acceptable alternative

### P - Perform
Who will execute the decision once it is made? The performers:
- Must be identified before the decision is made, not after
- Should have a voice in the decision-making process since they need to believe it is implementable
- Need clear authority and resources to carry out the decision

### I - Input
Whose input should be sought before the decision is made? Input providers:
- Provide facts, analysis, or judgment that improve the quality of the decision
- Are consulted, not required to approve
- The recommender should seek input but is not obligated to follow it
- Keep the input group small and relevant. Too many input providers slow decisions without improving quality.

### D - Decide
Who makes the final call? The decider:
- Should be a single person (or at most a very small group)
- Brings the decision to closure and commits the organization to action
- Should be the person who is best positioned to make the trade-offs the decision requires
- The decider should not also be the recommender (separation provides better quality)

## The RAPID Principle

**For any given decision, there should be exactly one D.** If you cannot identify a single decider, the decision will stall.

## Application Methodology

### Step 1: Identify Stuck Decisions
List the 5-10 decisions that are most frequently delayed, revisited, or unclear in the organization.

### Step 2: Map Current Roles
For each stuck decision, ask:
- Who currently recommends?
- Who has veto power (agree)?
- Who provides input?
- Who decides?
- Who executes?

Often you will find: multiple people think they are the decider, nobody has clear recommend responsibility, too many people have implicit veto power, and the performers are not involved early enough.

### Step 3: Redesign the RAPID

For each decision:
- Assign ONE recommender (or a small team)
- Minimize agree roles (only where legally or regulatorily required)
- Keep input providers to 3-5 relevant people
- Assign ONE decider
- Identify performers and involve them from the start

### Step 4: Communicate and Enforce

Publish the RAPID assignments. When decisions come up, follow the process. When someone outside their role tries to override or delay, refer back to the RAPID.

## RAPID Assignment Template

| Decision | R (Recommend) | A (Agree) | P (Perform) | I (Input) | D (Decide) |
|---|---|---|---|---|---|
| [Decision 1] | [Name/Role] | [Name/Role or None] | [Name/Role] | [Names/Roles] | [Name/Role] |
| [Decision 2] | [Name/Role] | [Name/Role or None] | [Name/Role] | [Names/Roles] | [Name/Role] |

## Common Pitfalls

- Assigning multiple deciders (guarantees stalling)
- Giving agree (veto) power to too many people
- Confusing input with agree (people who should be consulted believe they have veto power)
- Not involving performers early enough
- Designing RAPID on paper but not enforcing it in practice
- Over-engineering for simple decisions (RAPID is most valuable for cross-functional, high-stakes decisions)

## When to Use RAPID

RAPID is most valuable for:
- Decisions that cross organizational boundaries
- High-stakes strategic decisions
- Decisions that have historically been slow or contentious
- Situations where multiple people believe they own the same decision
- Post-merger integration (combining two decision-making cultures)

For routine, within-team decisions, RAPID is overkill. Use it surgically on the decisions that matter most.
