# Resume Scoring Rubric — Detailed Criteria

Full grading guide for all 10 dimensions. Each dimension scored 1–10, weighted to produce overall score out of 100.

---

## 1. Impact & Achievements (Weight: 20%)

The single most important dimension. Hiring managers scan for *results*, not duties.

**9–10 (Exceptional):**
- 80%+ bullets are achievement-oriented
- Quantified metrics in most bullets (revenue, %, team size, efficiency gains, user counts)
- CAR framework (Challenge → Action → Result) used naturally
- Strong, varied action verbs (led, architected, transformed, reduced, generated, launched)
- Achievements are specific and differentiated
- Career progression visible through escalating impact

**7–8 (Strong):** 60%+ bullets achievement-oriented, some metrics, good verbs with minor repetition.

**5–6 (Average):** 50/50 duty/achievement mix, few metrics, some weak openers ("Responsible for").

**3–4 (Weak):** Mostly duty-based, no/minimal quantification, passive verbs, JD-like language.

**1–2 (Critical):** Entirely duty-based or paragraph-form descriptions, zero metrics, passive voice throughout.

**Red Flags:** "Responsible for...", "Assisted with...", "Various/multiple" instead of numbers, same verb 3+ times, bullets starting with "I", bullets >2 lines.

**Strong Action Verbs:**
- Leadership: Directed, Orchestrated, Spearheaded, Championed, Mobilized
- Achievement: Exceeded, Surpassed, Outperformed, Earned, Captured
- Creation: Designed, Architected, Pioneered, Engineered, Launched
- Improvement: Streamlined, Optimized, Revamped, Accelerated, Transformed
- Analysis: Diagnosed, Evaluated, Quantified, Forecasted, Modeled
- Communication: Negotiated, Advocated, Influenced, Presented, Published

---

## 2. ATS Compatibility (Weight: 15%)

75%+ of resumes get filtered by ATS before a human sees them.

**9–10:** Clean single-column, standard headers, no tables/graphics for critical info, consistent dates, good keyword density, standard file format.
**7–8:** Mostly parsable, minor issues (one unusual header, slightly inconsistent dates).
**5–6:** Some parsing risks (two-column layout, info in headers/footers, non-standard headings).
**3–4:** Significant risks (tables for layout, icons for contact info, creative section names).
**1–2:** Likely fails ATS (image-heavy, infographic style, critical info in graphics).

**Checks:** Single-column layout, standard section headings, no critical info in headers/footers, no tables for layout, no text boxes, contact info as plain text, consistent date formats, PDF or DOCX format, skills as text not bars/charts, no white-text keyword stuffing.

**ATS-Safe Section Headings:** "Professional Experience" / "Work Experience", "Education", "Skills" / "Technical Skills" / "Core Competencies", "Professional Summary" / "Summary", "Certifications", "Projects", "Awards"

**Avoid:** "My Story", "What I Bring", "Career Highlights", "Superpowers", "Toolbox"

---

## 3. Content Relevance (Weight: 12%)

Signal-to-noise ratio. Every line earns its space.

**9–10:** Every bullet relevant and substantive, no filler, tailored to target role, recent experience gets most space.
**5–6:** Some irrelevant content, older roles get equal/more space than recent, generic content.
**1–2:** Mostly irrelevant, reads as life history not career marketing doc.

**Filler Phrases to Flag:** "Excellent communication skills", "Team player", "Detail-oriented", "Hard worker", "Self-motivated", "References available upon request", "Seeking a challenging role..."

---

## 4. Structure & Flow (Weight: 10%)

**9–10:** Perfect hierarchy, most important content first, clear visual separation, passes 6-second scan test, reverse chronological.
**5–6:** Adequate but suboptimal ordering, some difficulty finding key info.
**1–2:** No clear structure, information randomly placed.

**Recommended Order:** Contact → Summary (2–4 lines) → Experience (reverse chron) → Skills → Education → Certifications → Projects/Volunteer
**Exceptions:** Fresh grads can put Education first. Academic CVs have different conventions.

---

## 5. Formatting & Readability (Weight: 10%)

**9–10:** Clean, consistent, appropriate length (1 page <10yr exp, 2 max senior), adequate whitespace, professional.
**5–6:** Readable but not polished, some consistency issues.
**1–2:** Severely over/under-formatted, text walls or over-designed.

**Length:** 0–5yr = 1 page, 5–15yr = 1–2 pages, 15+yr = 2 pages, Academic CV = no limit, Federal = often longer.

---

## 6. Language & Grammar (Weight: 8%)

Consistent tense (past for past roles, present for current), no spelling/grammar errors, active voice preferred, professional tone, no first-person pronouns, no unexplained abbreviations, parallel structure in bullet lists.

---

## 7. Skills Presentation (Weight: 8%)

**9–10:** Skills categorized (Languages, Frameworks, Tools, Methodologies), relevant skills prominent, no obsolete tech, proficiency levels where helpful.
**5–6:** Skills present but disorganized/generic, missing key skills for target role.
**1–2:** No skills section or entirely generic/irrelevant.

---

## 8. Career Narrative (Weight: 7%)

Career progression visible? Gaps explained? Transitions logical? Career changer pivot clear? Short tenures (<1yr) flagged if 3+ consecutive? Trajectory going up?

---

## 9. Digital Presence (Weight: 5%)

Professional email, LinkedIn URL (ideally customized), GitHub/GitLab (technical roles), portfolio (creative), personal site (if relevant). Links should be clickable URLs, not just "LinkedIn: John Smith".

---

## 10. Compliance & Red Flags (Weight: 5%)

**Red Flags:** Photo (risky in US/UK/Canada/AU), DOB/age, marital status, religious/political affiliations (unless role-relevant), full address (city+state sufficient), low GPA included, graduation dates revealing age (20+ years ago), unprofessional email, "References available upon request".

**Geography Sensitivity:** EU/Asia often expect photos and DOB. Germany expects full address, photo, DOB. US/UK/Canada/AU discourage photos and DOB. When in doubt, ask about target market.

---

## Scoring Formula

```
Overall Score = Σ (dimension_score × weight) / Σ weights × 10
```

**Grade Mapping:**
90–100 = A+ | 85–89 = A | 80–84 = A- | 75–79 = B+ | 70–74 = B | 65–69 = B-
60–64 = C+ | 55–59 = C | 50–54 = C- | 45–49 = D+ | 40–44 = D | <40 = F
