# Idea Tester — Claude Skill

**Test and validate business ideas with 44 proven experiments before spending time and money building.**

## Quick Install

1. Download [`idea-tester.skill`](idea-tester.skill)
2. Go to [claude.ai](https://claude.ai) → Settings → Profile → Skills → Add Skill
3. Upload the file
4. Describe your idea and say **"Help me test this idea"**

## What It Does

Takes any business idea and helps you systematically reduce risk by:

1. **Shaping** the idea using Value Proposition Canvas and Business Model Canvas
2. **Extracting hypotheses** across three risk types (Desirability, Viability, Feasibility)
3. **Prioritizing** what to test first using the Assumptions Map
4. **Selecting experiments** from a library of 44 proven techniques
5. **Designing Test Cards** with clear success criteria before you run anything
6. **Analysing results** with Learning Cards and evidence strength assessment
7. **Deciding** whether to Persevere, Pivot, or Kill based on evidence

## The 44 Experiments

### Discovery (Cheap and Fast — Do These First)

| Category | Experiments |
|----------|------------|
| **Exploration** | Customer Interview, Expert Interview, Partner Interview, A Day in the Life, Discovery Survey |
| **Data Analysis** | Search Trend Analysis, Web Traffic Analysis, Discussion Forums, Sales Force Feedback, Customer Support Analysis |
| **Interest Discovery** | Online Ad, Link Tracking, Fake Door / 404 Test, Feature Stub, Email Campaign, Social Media Campaign, Referral Program |
| **Discussion Prototypes** | 3D Print, Paper Prototype, Storyboard, Data Sheet, Brochure, Boomerang, Explainer Video, Product Box, Speed Boat, Card Sorting, Buy a Feature |

### Validation (Stronger Evidence — Do After Discovery)

| Category | Experiments |
|----------|------------|
| **Prototypes** | Clickable Prototype, Single Feature MVP, Mash-Up MVP, Concierge, Wizard of Oz, Life-Size Prototype |
| **Call to Action** | Landing Page / Smoke Test, Presale, Crowdfunding, Split Test, Letter of Intent, Mock Sale |
| **Advanced** | Pop-Up Store, Extreme Programming Spike, Simulated Sale, Pre-Order with Deposit |

## Example Prompts

```
I have a business idea. Help me test it before I build anything.
```
```
I want to start a subscription box for pet owners in India.
What experiments should I run first?
```
```
Help me create a Test Card for a landing page experiment
for my SaaS product.
```
```
I ran customer interviews and got mixed signals.
Help me analyse the evidence and decide next steps.
```
```
Should I build an MVP or test more first?
Here's what I know so far: [describe evidence]
```

## Evidence Strength Hierarchy

| Level | Type | Example |
|-------|------|---------|
| Weakest | Opinions | "I would buy that" |
| Weak | Interest | Ad clicks, page views |
| Moderate | Engagement | Sign-ups, time on site |
| Strong | Behavioral | Account creation, onboarding |
| Very Strong | Financial | Pre-order, deposit, purchase |
| Strongest | Repeated | Repeat purchase, referral |

## Skill Contents

| File | Purpose |
|------|---------|
| `SKILL.md` | Core instructions — 5-phase workflow, framework selection, emerging market adaptations |
| `references/testing-process.md` | Detailed methodology — hypotheses, Assumptions Map, Test Card, Learning Card, decision framework |
| `references/experiment-library.md` | All 44 experiments with cost, evidence strength, and selection decision tree |
| `references/experiment-sequences.md` | How to chain experiments for B2B, B2C, B2B2C, fintech, and physical products |
