# Building Your Company's Vision

Source: James C. Collins and Jerry I. Porras, Harvard Business Review

## Core Concept

Companies that endure ("built to last") have a well-conceived vision consisting of two major components: Core Ideology (what we stand for and why we exist, which never changes) and Envisioned Future (what we aspire to become and achieve, which requires significant change and progress).

## The Vision Framework

```
VISION = Core Ideology + Envisioned Future

Core Ideology (PRESERVE)          Envisioned Future (STIMULATE PROGRESS)
  - Core Values                     - BHAG (10-30 year audacious goal)
  - Core Purpose                    - Vivid Description
```

### Core Ideology

**Core Values** - The handful of guiding principles by which a company navigates. They require no external justification. You do not "create" or "set" core values. You DISCOVER them. They are already there.

How to identify core values:
- If conditions changed and penalized us for holding this value, would we still keep it?
- If we woke up tomorrow with enough money to retire, would we continue to apply this value?
- Can you envision this value being as valid 100 years from now?
- Would you want to hold this value even if it became a competitive DISADVANTAGE?

A company should have only 3-5 core values. More than that means you are confusing values with practices.

**Core Purpose** - The organization's fundamental reason for existence beyond just making money. It should be broad, enduring, and inspiring. A good purpose can guide and inspire for 100+ years.

The "Five Whys" method: Start with "We make X products" and ask "Why is that important?" five times. You eventually arrive at the fundamental purpose.

Examples:
- 3M: "To solve unsolved problems innovatively"
- Wal-Mart: "To give ordinary folk the chance to buy the same things as rich people"
- Walt Disney: "To make people happy"

### Envisioned Future

**BHAG (Big Hairy Audacious Goal)** - A clear, compelling, 10-to-30-year goal. It should be so bold that there is roughly a 50-70% probability of success. It should require extraordinary effort.

Types of BHAGs:
- **Target BHAGs** - quantitative or clearly defined goals ("Become a $125 billion company by year 2000" - Wal-Mart in 1990)
- **Common-enemy BHAGs** - defeat a specific competitor ("Crush Adidas" - Nike in 1960s)
- **Role-model BHAGs** - become like a specific admired company ("Become the Nike of the cycling industry" - Giro Sport Design)
- **Internal-transformation BHAGs** - fundamental change ("Become the company most known for changing the worldwide poor-quality image of Japanese products" - Sony in 1950s)

A BHAG should NOT need to be explained. People should get it instantly.

**Vivid Description** - A vibrant, engaging, tangible description of what it will be like to achieve the BHAG. It should paint a picture that people can see and feel.

## Application Methodology

1. **Discover core values** - Assemble a "Mars Group" (5-7 people who embody the company's best). Ask them to identify 3-5 values they would hold regardless of circumstances.
2. **Articulate core purpose** - Use the Five Whys. Test: would this purpose be equally valid 100 years from now?
3. **Set the BHAG** - What 10-30 year goal would energize the entire organization? Is it audacious enough? Could you explain it in 30 seconds?
4. **Write the vivid description** - Translate the BHAG into a concrete, emotional picture of what success looks like.
5. **Align** - Check that strategies, goals, and activities serve both the core ideology AND progress toward the envisioned future.

## Common Pitfalls

- Confusing core values with aspirational values (core values describe who you ARE, not who you want to be)
- Making BHAGs that are too safe or too easy
- Changing core purpose every few years (purpose is timeless)
- Confusing core purpose with a specific strategy or business model
- Having too many values (if you have 15 values, you have zero values)
