# Experiment Sequences

Experiments work best in sequences. Each experiment builds on the previous one, progressively generating stronger evidence. Here are proven sequences for different business types.

## General Principle

```
DISCOVERY (cheap, fast, weak evidence)
  --> Interviews + Data Analysis + Interest Tests
  --> 2-4 weeks, under Rs 10,000

VALIDATION (costlier, stronger evidence)  
  --> Prototypes + Call-to-Action + Financial Commitment
  --> 2-8 weeks, Rs 10,000 - Rs 1,00,000

SCALE DECISION
  --> Evidence strong enough to commit significant resources
```

Always move from weak evidence to strong evidence. Never skip discovery.

## B2B Software Sequence

```
Step 1: Expert Stakeholder Interviews (5-10 people)
   --> Understand the problem landscape and industry dynamics
   
Step 2: Customer Interviews (15-20 target buyers)
   --> Validate jobs, pains, gains with the people who would buy
   
Step 3: Data Sheet or Brochure
   --> Create a product spec sheet and share with interview contacts
   --> Measure: Do they forward it? Ask for pricing? Request a demo?
   
Step 4: Letter of Intent
   --> Ask 3-5 strongest prospects to sign a non-binding LOI
   --> If they will not sign even non-binding, demand is weak
   
Step 5: Concierge or Wizard of Oz
   --> Deliver the value manually to 2-3 paying customers
   --> Validate that the solution actually solves their problem
   
Step 6: Single Feature MVP
   --> Build the one core feature and deploy to early customers
```

## B2C Product Sequence

```
Step 1: Customer Interviews (15-20 target users)
   --> Understand the job-to-be-done and current alternatives
   
Step 2: Search Trend Analysis + Discussion Forums
   --> Validate that enough people have this problem (market size signal)
   
Step 3: Explainer Video + Landing Page
   --> Create a video explaining the solution + landing page with sign-up
   --> Drive traffic via social media or ads
   --> Measure: conversion rate, sign-up count
   
Step 4: Email Campaign to Sign-Ups
   --> Engage sign-ups with updates, get feedback on features and pricing
   
Step 5: Presale or Crowdfunding
   --> Take actual pre-orders or launch on a crowdfunding platform
   --> Money received = strongest validation of demand
   
Step 6: Concierge or Mash-Up MVP
   --> Deliver value to first paying customers using manual or no-code tools
```

## B2C Services Sequence

```
Step 1: Customer Interviews + A Day in the Life
   --> Understand the customer's actual workflow and pain points
   
Step 2: Social Media Campaign
   --> Post about the problem on relevant channels
   --> Measure engagement, DMs, comments asking "where can I get this?"
   
Step 3: Online Ad + Landing Page
   --> Run targeted ads to a landing page with clear value prop and pricing
   --> Measure: click-through rate, sign-up rate
   
Step 4: Presale
   --> Offer the service at a specific price to landing page sign-ups
   --> Even 5-10 presales validates demand
   
Step 5: Concierge
   --> Deliver the service manually to first customers
   --> Learn what the actual delivery looks like before building systems
```

## B2B2C (Platform / Marketplace) Sequence

B2B2C businesses have a unique challenge: they must validate BOTH sides of the marketplace.

```
SUPPLY SIDE:
Step 1: Partner and Supplier Interviews
   --> Will partners/suppliers join your platform? On what terms?
   
Step 2: Letter of Intent from supply side
   --> Get 3-5 supply-side partners to commit (even non-binding)

DEMAND SIDE:
Step 3: Customer Interviews
   --> Validate end-customer demand independently of the supply side
   
Step 4: Landing Page + Online Ad
   --> Test demand-side interest with a landing page

BOTH SIDES:
Step 5: Concierge
   --> Manually match supply and demand for 10-20 transactions
   --> Learn unit economics, fulfillment challenges, customer satisfaction
   
Step 6: Mash-Up MVP
   --> Build minimal platform using no-code tools
   --> Test if both sides will use a self-serve platform
```

## Financial Services / Lending Sequence

```
Step 1: Customer Interviews in target geography
   --> Understand borrower pain points with existing options
   --> What matters most: rate, speed, documentation ease, trust?
   
Step 2: Partner/Supplier Interviews
   --> Talk to potential bank/NBFC partners about product fit
   --> Validate regulatory feasibility early
   
Step 3: Sales Force Feedback (if existing team)
   --> What are field teams hearing? What objections come up?
   
Step 4: Data Sheet + Brochure
   --> Create product collateral with proposed terms
   --> Share with target customers and partners
   
Step 5: Simulated Sale / Mock Sale
   --> Walk target borrowers through the full application process
   --> Measure: completion rate, document readiness, drop-off points
   
Step 6: Concierge (manual underwriting for first N loans)
   --> Process first loans with manual workflows
   --> Validate TAT, unit economics, default risk assumptions
```

## Physical Product Sequence

```
Step 1: Customer Interviews
Step 2: Paper Prototype or 3D Print Prototype
   --> Show customers a rough version, get feedback on concept
Step 3: Explainer Video
   --> Show how the product works, measure interest
Step 4: Crowdfunding
   --> Launch on Kickstarter or equivalent with production-ready design
Step 5: Pop-Up Store or Pre-Order
   --> Test real purchase behavior in a physical setting
Step 6: Small Batch Production
   --> Produce and sell first batch to validate manufacturing and delivery
```

## Experiment Pairing Rules

These experiments work well together:

| First Experiment | Natural Next Step | Why |
|---|---|---|
| Customer Interview | Survey | Interviews find patterns, surveys quantify them |
| Online Ad | Landing Page | Ad tests the hook, landing page tests conversion |
| Landing Page | Presale | Sign-ups show interest, payment shows commitment |
| Data Sheet | Letter of Intent | Spec sheet generates interest, LOI confirms buying intent |
| Concierge | Single Feature MVP | Manual delivery validates value, MVP tests scalability |
| Paper Prototype | Clickable Prototype | Paper tests concept, clickable tests usability |
| Explainer Video | Crowdfunding | Video generates excitement, crowdfunding converts it to money |
| Feature Stub | Split Test | Stub measures interest, split test optimizes conversion |

## How Many Experiments Do You Need?

**Before spending significant money building:** Minimum 3-5 experiments generating converging evidence across at least 2 evidence strength levels.

**Before hiring a team:** At least one experiment with financial commitment (presale, deposit, LOI).

**Before raising investment:** A mix of discovery and validation experiments showing both desirability and viability evidence. Investors look for behavioral evidence, not just survey data.

**Rule of thumb:** No single experiment is ever enough. If only one experiment supports your idea, you do not have enough evidence.
