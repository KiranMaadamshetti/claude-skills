# Blue Ocean Strategy

Source: W. Chan Kim and Renee Mauborgne, Harvard Business Review

## Core Concept

Instead of competing head-to-head in existing industries (red oceans, bloody with competition), create uncontested market space (blue oceans) where competition is irrelevant. Blue oceans are created by simultaneously pursuing differentiation AND low cost, not choosing between them.

**Key insight:** The most profitable growth comes from creating new demand among non-customers, not fighting over existing customers.

## The Strategy Canvas

A diagnostic tool that plots an industry's competitive factors on the horizontal axis and the level of offering on the vertical axis. Drawing the value curves of competitors reveals:
- Where the industry competes (which factors get investment)
- Where competitors converge (same value curve shape = red ocean)
- Opportunities to break away

## The Four Actions Framework

To create a blue ocean, apply four questions to every factor the industry competes on:

### ELIMINATE
Which factors that the industry takes for granted should be eliminated entirely?
- These are factors that no longer create value but persist out of habit
- Removing them reduces cost dramatically

### REDUCE
Which factors should be reduced well below the industry standard?
- Over-designed or over-delivered features that raise costs without matching value
- Challenge the "more is better" assumption

### RAISE
Which factors should be raised well above the industry standard?
- Factors where the industry forces customers to accept compromises
- Addressing these creates a jump in buyer value

### CREATE
Which factors should be created that the industry has never offered?
- These create entirely new sources of value and new demand
- Often found by looking at alternative industries, not just competitors

## The Six Paths Framework (Finding Blue Oceans)

Six ways to reconstruct market boundaries:

1. **Look across alternative industries** - What industry does your product substitute for? What makes buyers switch between them?
2. **Look across strategic groups within the industry** - What makes buyers trade up or down between groups?
3. **Look across the chain of buyers** - Who are the purchasers, users, and influencers? Which group does your industry focus on, and what happens if you shift focus?
4. **Look across complementary product and service offerings** - What happens before, during, and after your product is used? What pain points exist in the total solution?
5. **Look across functional or emotional appeal** - Does your industry compete on function or emotion? What if you switched?
6. **Look across time** - What trends are creating irreversible change? How can you shape them?

## Three Tiers of Non-Customers

Blue oceans are found among non-customers:
- **Tier 1:** "Soon-to-be" non-customers who minimally use the current offering but are mentally ready to leave
- **Tier 2:** "Refusing" non-customers who have consciously rejected the industry's offerings
- **Tier 3:** "Unexplored" non-customers who have never considered the industry's offerings as an option

## Application Methodology

1. **Draw the current strategy canvas** - plot your value curve and competitors'
2. **Identify convergence** - where are all players investing in the same factors?
3. **Apply the Four Actions Framework** to each factor
4. **Explore the Six Paths** to find new value-cost frontiers
5. **Map non-customers** across three tiers to size the opportunity
6. **Draw the new strategy canvas** - your value curve should diverge sharply from competitors
7. **Test:** Does the new curve have focus, divergence, and a compelling tagline?

## ERRC Grid Template

| Eliminate | Reduce |
|---|---|
| [factors to eliminate] | [factors to reduce] |
| **Raise** | **Create** |
| [factors to raise] | [factors to create] |

## Common Pitfalls

- Treating blue ocean as "just innovation" (it is strategic reconstruction of market boundaries, not just product innovation)
- Focusing only on existing customers instead of non-customers
- Raising everything (that is just spending more, not creating a blue ocean)
- Ignoring the cost side (true blue ocean reduces costs simultaneously)
- Assuming blue oceans are permanent (they eventually become red oceans as imitators arrive)
