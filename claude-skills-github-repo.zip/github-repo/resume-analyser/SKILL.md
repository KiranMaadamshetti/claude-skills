---
name: resume-analyser
description: >-
  Intensive, multi-dimensional resume analyser that scores, critiques,
  AND rewrites resumes. Use this skill whenever a user uploads a resume
  or CV and wants it reviewed, analysed, scored, improved, rewritten, or
  optimized. Triggers include review my resume, analyse my CV, score my
  resume, how good is my resume, help me improve my resume, rewrite my
  resume, is my resume ATS-friendly, tailor my resume for a role, fix my
  resume, or any mention of resume or CV critique, feedback, or
  optimization. Also trigger when the user uploads a PDF or DOCX and
  mentions job applications, career, hiring, or interviews in the same
  message. This skill produces TWO deliverables - a comprehensive
  analysis report with scores and a complete rewritten resume ready to
  copy-paste. Always trigger this skill even for casual resume review
  requests.
---

# Intensive Resume Analyser + Rewriter

## What This Skill Produces

Two deliverables every time:

1. **Analysis Report** (HTML) with 10-dimension scoring, section-by-section critique, ATS audit, before/after comparisons, and priority action plan
2. **Revised Resume** (HTML with copy button + Markdown file) with a complete, polished, ready-to-use rewrite of the entire resume incorporating all improvements

Both are delivered in a single interactive HTML report with tabs.

## Workflow

```
Step 1 -> Extract resume content (PDF/DOCX/TXT -> text)
Step 2 -> Parse into sections and catalogue every bullet
Step 3 -> Run 10-dimension analysis using references/scoring-rubric.md
Step 4 -> ATS compatibility audit (+ JD matching if provided)
Step 5 -> Generate section-by-section critique with before->after rewrites
Step 6 -> Write the COMPLETE revised resume from scratch
Step 7 -> Build combined HTML report (Analysis tab + Revised Resume tab)
Step 8 -> Also save revised resume as standalone .md file
Step 9 -> Deliver both files + conversational summary
```

## Step 1: Extract Resume Content

Determine file type and extract properly.

**PDF:**
```python
from pypdf import PdfReader
reader = PdfReader("/mnt/user-data/uploads/resume.pdf")
full_text = ""
for i, page in enumerate(reader.pages):
    full_text += f"\n--- Page {i+1} ---\n"
    full_text += page.extract_text()
```
If text extraction yields garbage (scanned PDF), fall back to OCR:
```bash
pdftoppm -r 300 -png /mnt/user-data/uploads/resume.pdf /tmp/resume_page
for f in /tmp/resume_page*.png; do tesseract "$f" - >> /tmp/resume_ocr.txt; done
```

**DOCX:**
```bash
pandoc /mnt/user-data/uploads/resume.docx -t plain
```

**Plain text:** `cat` directly.

Also compute word count and page count for the meta section.

## Step 2: Parse Into Sections

Identify every section present in the resume:
- Contact Information, Professional Summary/Objective, Work Experience, Education, Skills, Certifications, Projects, Awards, Volunteer, Publications

Also identify:
- **Missing critical sections** (no summary, no skills section)
- **Sections that should be removed** (Declaration, Personal Details with DOB/father name/marital status which are common in Indian resumes but harmful for modern hiring)
- **Total bullet count** and per-role bullet count

## Step 3: Score Across 10 Dimensions

Read `references/scoring-rubric.md` for the full grading criteria. Summary:

| # | Dimension | Weight | Focus |
|---|-----------|--------|-------|
| 1 | Impact and Achievements | 20% | Quantified results, action verbs, CAR framework |
| 2 | ATS Compatibility | 15% | Parsability, keywords, format |
| 3 | Content Relevance | 12% | Signal-to-noise, filler detection |
| 4 | Structure and Flow | 10% | Section order, information hierarchy |
| 5 | Formatting and Readability | 10% | Consistency, length, whitespace |
| 6 | Language and Grammar | 8% | Tense, voice, tone, spelling |
| 7 | Skills Presentation | 8% | Categorization, specificity |
| 8 | Career Narrative | 7% | Progression, gap handling |
| 9 | Digital Presence | 5% | LinkedIn, GitHub, portfolio |
| 10 | Compliance and Red Flags | 5% | PII, discrimination risk |

Score each 1-10, compute weighted total out of 100.

## Step 4: ATS Deep Dive

Check parsing risks, keyword density, standard headers, date format consistency, file format. If user provided a job description, compute keyword match rate and identify gaps.

## Step 5: Section-by-Section Critique

For each section provide:
1. Strengths (always lead with positives)
2. Issues tagged as Critical, Important, or Minor
3. Specific before to after rewrites for the weakest content

**Experience bullets get special attention:** evaluate every bullet for action verb strength, quantification, specificity, and CAR framework compliance.

## Step 6: Write the Complete Revised Resume

This is what makes this skill different. Do not just critique. Rewrite the entire resume.

### Revised Resume Rules

1. **Keep all facts truthful.** Never fabricate achievements, companies, dates, or degrees. Only reframe, restructure, and strengthen what is already there.

2. **Infer reasonable metrics where possible.** If someone managed a team, structure it as Led team of [X] members with a placeholder [X] the user can fill in. Use [PLACEHOLDER: description] markers for numbers the user needs to supply, and flag every placeholder clearly.

3. **Apply the CAR framework to every experience bullet:**
   - Challenge: What was the context or problem?
   - Action: What did the candidate specifically do?
   - Result: What was the measurable outcome?
   
   Not every bullet needs all three elements, but every bullet MUST have an action verb + specificity. At least 60% should have quantified results (or placeholders).

4. **Restructure the entire document:**
   - Remove: Objective statements (replace with Professional Summary), Personal Details sections (DOB, father name, marital status, nationality), Declaration sections, References available upon request
   - Add: Professional Summary (3-4 lines with key value proposition), properly categorized Skills section, LinkedIn URL placeholder
   - Reorder: Most impactful content first within each section

5. **Skills section must be categorized:**
   ```
   Technical Skills: [specific tools, platforms, software]
   Management and Operations: [methodologies, frameworks]
   Domain Expertise: [industry-specific knowledge]
   ```
   Remove generic soft skills (communication, team player). These should be demonstrated through achievement bullets, not listed.

6. **Professional Summary must be specific:**
   Not: Seeking a challenging position...
   But: [Title] with [X] years of experience in [specific domain], specializing in [2-3 key strengths]. Most recently [biggest recent achievement with metric]. Known for [differentiator].

7. **Format the revised resume in clean Markdown** that translates perfectly to any resume builder or word processor:
   ```markdown
   # FULL NAME
   email | phone | city, state | linkedin.com/in/handle
   
   ## Professional Summary
   [3-4 line summary]
   
   ## Professional Experience
   
   ### Job Title | Company Name
   **Month Year - Present** | Location
   
   - Achievement bullet with metric
   - Achievement bullet with metric
   
   ## Education
   
   ### Degree - Specialization
   **University Name** | Year - Year
   
   ## Skills
   **Category:** Skill1, Skill2, Skill3
   ```

8. **Mark every placeholder** that the user needs to fill in with [PLACEHOLDER: description] format so they can search and replace easily. At the end of the revised resume, include a Placeholders to Fill checklist.

### Revised Resume Quality Checklist (verify before output)
- Every experience bullet starts with a strong, varied action verb
- At least 60% of bullets have metrics or metric placeholders
- No duty-based language (Responsible for, Duties included)
- No first-person pronouns
- Consistent past tense for past roles, present for current
- Skills are categorized, not a flat list
- Professional Summary is specific and compelling
- Personal Details, Declaration, and Objective sections removed
- LinkedIn URL placeholder included
- All placeholders are clearly marked with [PLACEHOLDER: ...]
- Total length appropriate (1 page for under 10yr, 2 max for senior)

## Step 7: Build the Combined HTML Report

Generate a single self-contained HTML file with TWO TABS:

**Tab 1: Analysis Report**
- Overall score with grade circle
- Radar chart of 10 dimensions
- Score breakdown with bars and summaries
- Section-by-section expandable critique
- ATS audit with pass/fail checks
- Keyword analysis
- Priority action plan (top 5)

**Tab 2: Revised Resume**
- The complete rewritten resume rendered beautifully
- A Copy to Clipboard button at the top that copies the plain-text/markdown version
- A Placeholders to Fill section highlighted in a distinct color
- Print-friendly styling so the user can Ctrl+P to get a clean resume

Use the template from `scripts/generate_report.py`. Read it for the HTML structure and CSS. The report should:
- Be fully self-contained (inline CSS, inline JS, no external deps)
- Use dark theme with professional styling
- Have smooth tab transitions
- Be mobile-responsive
- Have a print stylesheet that only prints the resume tab cleanly

## Step 8: Save Revised Resume Separately

Also save the revised resume as a standalone Markdown file:
```
/mnt/user-data/outputs/revised_resume.md
```
This gives the user a clean file they can paste into any resume builder, Google Docs, or Word.

## Step 9: Deliver Results

1. Save HTML report to `/mnt/user-data/outputs/resume_analysis_report.html`
2. Save revised resume to `/mnt/user-data/outputs/revised_resume.md`
3. Present both files to the user
4. Give a conversational summary:
   - Overall score and grade
   - Number 1 biggest strength
   - Top 3 changes made in the revised version
   - ATS readiness status
   - How many placeholders the user needs to fill in
   - Offer to tailor further for a specific job description

## Role-Specific Tailoring (if JD provided)

When the user provides a target job description:
- Extract all required skills, qualifications, keywords from the JD
- Score resume-to-JD alignment percentage
- In the revised resume: reorder skills to front-load JD matches, weave JD keywords into achievement bullets where truthful, add missing skills as placeholders if the user might have them
- In the analysis: show a keyword gap matrix

## Tone and Approach

- **Honest but constructive.** Do not sugarcoat, but frame problems as solvable.
- **Specific, never vague.** Point to exact bullets, exact sections.
- **Lead with strengths.** Every resume has something working.
- **The revised resume is the real value.** The analysis explains why; the rewrite shows how. Most users will grab the revised resume and run, so make it excellent.
- **Respect context.** Fresh grad is different from senior exec. Career changer is different from linear climber. Indian resume conventions differ from US conventions. Calibrate accordingly.

## Edge Cases

- **Very short resume (under 200 words):** Flag as underdeveloped. Revised version should flesh out with placeholders.
- **Very long resume (over 3 pages, non-academic):** Revised version should trim aggressively.
- **Non-English:** Analyse and rewrite in the language of the resume.
- **Creative/design resumes:** Note visual design cannot be assessed from text. Focus on content.
- **No work experience (fresh grad):** Emphasize projects, education, internships, skills. Restructure accordingly.
- **Career gaps:** Address gracefully in revised version. Do not hide, reframe.

## What NOT to Do

- Never fabricate achievements, companies, or credentials
- Never assume gender, age, or ethnicity from names
- Never penalize non-Western name formats or international education
- Never recommend lying about gaps or experience
- Never include photos unless user asks and it is standard in their market
- Mark every inferred metric as a placeholder so the user can confirm
