# The Testing Process

## The Five Phases

### Phase 1: SHAPE (Business Design)

Map the idea using two canvases before doing anything else.

**Value Proposition Canvas:**

| Customer Profile | Value Map |
|---|---|
| **Customer Jobs:** Tasks they are trying to perform, problems they are trying to solve, needs they want to satisfy | **Products and Services:** What you offer |
| **Pains:** Negative outcomes, risks, obstacles they experience | **Pain Relievers:** How your offering eliminates or reduces pains |
| **Gains:** Outcomes and benefits they want | **Gain Creators:** How your offering creates customer gains |

**Business Model Canvas (9 blocks):**

| Key Partners | Key Activities | Value Proposition | Customer Relationships | Customer Segments |
|---|---|---|---|---|
| Who are critical partners and suppliers? | What key activities does the value proposition require? | What value do you deliver? Which customer problems do you solve? | What relationship does each segment expect? | Who are your most important customers? |
| **Key Resources** | | | **Channels** | |
| What key resources does the value proposition require? | | | Through which channels do segments want to be reached? | |
| **Cost Structure** | | | **Revenue Streams** | |
| What are the most important costs? | | | For what value are customers willing to pay? How do they pay? | |

### Phase 2: HYPOTHESIZE

**Writing Good Hypotheses:**

Format: "We believe that [specific, testable claim]"

Bad: "We believe customers will like our product"
Good: "We believe that millennial parents in urban India will pay Rs 500/month for curated STEM activity kits delivered to their home"

**Characteristics of good hypotheses:**
- Testable (you can design an experiment to confirm or refute it)
- Precise (specific customer segment, specific behavior, specific metric)
- Discrete (tests one thing, not five things bundled together)

**The Three Hypothesis Types:**

**Desirability Hypotheses** (customer risk):
- We believe [customer segment] experiences [specific pain/job]
- We believe [customer segment] will choose our solution over [alternative]
- We believe [customer segment] will pay [specific price] for [specific value]
- We believe [customer segment] will [specific behavior: sign up, refer, return]

**Feasibility Hypotheses** (execution risk):
- We believe we can build [specific capability] within [timeframe]
- We believe we can source [key resource] at [cost/quality]
- We believe [technology/process] will work at [scale]
- We believe we can deliver [value proposition] through [channel]

**Viability Hypotheses** (business model risk):
- We believe we can acquire customers at [CAC]
- We believe customers will have [LTV] over [time period]
- We believe our margins will be [X%] at [scale]
- We believe we can reach [revenue target] within [timeframe]

### The Assumptions Map

A 2x2 prioritization grid:

```
                    IMPORTANT
                        |
     Test These    |    Test These
     (have some    |    FIRST
      evidence)    |    (no evidence)
                   |
  ---- HAVE EVIDENCE ----+---- NO EVIDENCE ----
                   |
     Monitor       |    Investigate
     (low          |    Later
      priority)    |
                   |
                 UNIMPORTANT
```

**How to use it:**
1. Write each hypothesis on a sticky note (color-coded by type: desirability, feasibility, viability)
2. Place each on the map based on importance and existing evidence
3. Start testing from the top-right quadrant (important + no evidence)
4. Work your way through systematically

### Phase 3: EXPERIMENT

**The Test Card:**

For every experiment, fill out a Test Card BEFORE running:

```
TEST CARD

Step 1: Hypothesis
We believe that... [your hypothesis]

Step 2: Test
To verify that, we will... [experiment type and description]

Step 3: Metric
And measure... [what specific data you will collect]

Step 4: Criteria
We are right if... [specific threshold that determines success/failure]
```

**Example:**
```
Hypothesis: We believe that small business owners in Hyderabad 
            will pay Rs 2000/month for automated GST filing

Test: We will run a landing page with pricing and a 
      "Sign Up for Early Access" button for 2 weeks,
      driving traffic via Google Ads targeting 
      "GST filing Hyderabad"

Metric: Landing page conversion rate (visitors to sign-ups)

Criteria: We are right if at least 5% of visitors sign up 
          for early access
```

### Phase 4: LEARN

**The Learning Card:**

After each experiment, fill out a Learning Card:

```
LEARNING CARD

Step 1: Hypothesis
We believed that... [restate the hypothesis]

Step 2: Observation
We observed... [what actually happened, data collected]

Step 3: Learnings and Insights
From that we learned that... [key insights, surprises, patterns]

Step 4: Decisions and Actions
Therefore, we will... [persevere / pivot / kill + specific next steps]
```

**Evidence Strength Assessment:**

| Evidence Type | Strength | Example |
|---|---|---|
| Opinions | Weak | "I would definitely buy that" in an interview |
| Interest | Moderate-Weak | Email sign-up, clicking "Learn More" |
| Engagement | Moderate | Time spent on page, feature usage, return visits |
| Behavioral commitment | Moderate-Strong | Creating an account, completing onboarding |
| Financial commitment | Strong | Pre-order with payment, deposit, actual purchase |
| Repeated behavior | Very Strong | Repeat purchase, subscription renewal, referral |

**Confidence Level:**

Assess overall confidence by checking three dimensions:
1. **Type and strength of evidence** (opinions vs behavior vs payment)
2. **Number of data points** (5 interviews vs 500 landing page visitors)
3. **Convergence** (do multiple experiments point to the same conclusion?)

### Phase 5: DECIDE

Three possible decisions:

**Persevere** when:
- Evidence supports the hypothesis
- Confidence level is adequate for the decision stakes
- Next step: test next important hypothesis or run stronger experiment

**Pivot** when:
- Evidence partially refutes hypothesis but reveals new opportunity
- Some elements work, others do not
- Next step: modify value proposition or business model, then re-test

**Kill** when:
- Evidence strongly refutes the hypothesis
- No viable pivot direction visible
- Customer need does not exist, or business model cannot work
- Next step: stop investing, apply learnings to next idea

**Common Decision Traps:**
- Confirmation bias: seeking only evidence that confirms your belief
- Sunk cost fallacy: continuing because you already invested, not because evidence supports it
- Analysis paralysis: running endless experiments instead of deciding
- Premature scaling: scaling before evidence is strong enough
- Vanity metrics: celebrating metrics that feel good but do not indicate real demand (page views vs purchases)
