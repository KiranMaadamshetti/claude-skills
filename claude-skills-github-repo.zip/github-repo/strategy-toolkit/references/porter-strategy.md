# Porter's What Is Strategy

Source: Michael E. Porter, Harvard Business Review

## Core Concept

Strategy is NOT operational effectiveness. Operational effectiveness means performing similar activities better than rivals. Strategy means performing DIFFERENT activities from rivals, or performing similar activities in different ways. Both are essential, but only strategy creates sustainable competitive advantage.

**The trap:** When all competitors improve along the same dimensions (quality, speed, cost), they converge on best practices and nobody wins. This is competitive convergence. The result is a race nobody can win.

## The Three Tests of Strategy

A real strategy passes all three:

### Test 1: Unique Strategic Position
A company must serve customers in a way that is fundamentally different from competitors. Three bases for positioning:

- **Variety-based positioning** - Produce a subset of an industry's products or services better than anyone. (Example: Jiffy Lube does only auto lubricants, not general repair.)
- **Needs-based positioning** - Serve most or all needs of a particular customer segment. (Example: IKEA serves the complete home-furnishing needs of young, budget-conscious buyers.)
- **Access-based positioning** - Reach customers who are accessible in different ways due to geography, scale, or other factors. (Example: Carmike Cinemas targets small towns that cannot support multiple theaters.)

### Test 2: Trade-offs
Strategy requires choosing what NOT to do. Trade-offs arise from:
- Activities that are incompatible (a luxury brand cannot also be a discount retailer)
- Image or reputation inconsistencies
- Limits of internal coordination and control

**Key question:** "If someone asked our competitors to copy our strategy, what would they have to give up?" If the answer is "nothing," you do not have a strategy.

### Test 3: Fit Among Activities
The most sustainable strategies involve a system of activities that reinforce each other. Three types of fit:
- **Simple consistency** - each activity aligns with overall strategy
- **Activities reinforce each other** - each activity makes others more valuable
- **Optimization of effort** - coordination and information exchange across activities reduce redundancy

When a strategy involves dozens of reinforcing activities, it becomes extremely hard to copy even if individual activities seem simple.

## Activity System Mapping

A powerful tool for making strategy tangible. Draw a map showing:
- Core strategic themes (3-5 big circles in the center)
- Supporting activities (smaller circles connected to themes)
- Lines showing which activities reinforce which

This reveals whether activities truly fit together or are a random collection.

## Application Methodology

When helping a user define or assess their strategy:

1. **Ask:** What activities do you perform differently from competitors?
2. **Test for OE vs Strategy:** Are your advantages from doing the same things better, or doing different things?
3. **Map the activity system:** List 15-20 key activities, draw connections, check for fit
4. **Identify trade-offs:** What have you explicitly chosen NOT to do? What would competitors have to sacrifice to copy you?
5. **Check for straddling risk:** Is a competitor trying to match your position while maintaining their own? (Straddles usually fail because of trade-offs.)
6. **Evaluate sustainability:** Does your system of activities create compounding advantages over time?

## Common Pitfalls

- Confusing operational excellence with strategy
- Failing to make trade-offs (trying to be everything to everyone)
- Defining strategy as a vision or aspiration rather than a set of concrete choices
- Benchmarking against competitors leads to convergence, not differentiation
- Treating strategy as a one-time event rather than a reinforcing system of activities
